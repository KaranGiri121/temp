package com.example.filesmanager.Activity

import android.os.Bundle
import android.util.Log
import android.view.View.GONE
import android.view.View.VISIBLE
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.filesmanager.Adapter.StoreFilesAdapter
import com.example.filesmanager.Model.QuickFileModel
import com.example.filesmanager.Utils.AppConstant
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.databinding.ActivityStoreFileScreenBinding
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class StoreFileScreen : AppCompatActivity() {
    private lateinit var binding: ActivityStoreFileScreenBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStoreFileScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val deleteFiles: MutableStateFlow<MutableList<QuickFileModel>> = MutableStateFlow(
            mutableListOf()
        )
        val deleteSize: MutableStateFlow<Long> = MutableStateFlow(0L)
        val adapter = StoreFilesAdapter(this, AppConstant.storeFileList,deleteFiles,deleteSize)
        lifecycleScope.launch {
            deleteSize.collectLatest {
                Log.e("TAG", "onCreate: $it", )
                if(it>0){
                    binding.llCleanBottom.visibility = VISIBLE
                    binding.tvFinalTotalClean.text = Helper.formatSize(it)
                }else{
                    binding.llCleanBottom.visibility = GONE
                }
            }
        }
        binding.rvStoreFile.adapter = adapter
        binding.rvStoreFile.layoutManager = LinearLayoutManager(this)
    }
}