package com.example.filesmanager.Adapter

import android.app.Activity
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.filesmanager.R

class FaqHeadingAdapter(val context: Activity, val arr: Map<String, List<Pair<String, String>>>) :
    RecyclerView.Adapter<FaqHeadingAdapter.ViewHolder>() {

    val questionHeading = arr.keys.toList()

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val heading: TextView = itemView.findViewById(R.id.tv_section_heading)
        val body: LinearLayout = itemView.findViewById(R.id.body)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.faq_section, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return arr.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.heading.text = questionHeading[holder.absoluteAdapterPosition]
        val questionAnswer = arr[questionHeading[holder.absoluteAdapterPosition]]!!
        val adapter = QuestionAnswerAdapter(context,questionAnswer)
        for(i in questionAnswer.indices){
            val view = adapter.getView(i,null,holder.body)
            holder.body.addView(view)
        }
    }
}