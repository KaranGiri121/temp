package com.example.filesmanager.Utils

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.WindowMetrics
import androidx.lifecycle.MutableLiveData
import com.example.filesmanager.Activity.HomeScreen
import com.example.filesmanager.Activity.MainActivity
import com.google.ads.mediation.admob.AdMobAdapter
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

class AdLoader {
    companion object {
        var nativeAd: NativeAd? = null
        var interstitialAd: InterstitialAd? = null
        fun loadInterstitialAd(id: String, activity: Activity) {
            val adRequest = AdRequest.Builder().build()

            InterstitialAd.load(
                activity, id, adRequest,
                object : InterstitialAdLoadCallback() {
                    override fun onAdFailedToLoad(adError: LoadAdError) {
                    }

                    override fun onAdLoaded(interstitial: InterstitialAd) {
                        interstitialAd = interstitial
                    }
                },
            )
        }

        var rewardAdLoaded: MutableLiveData<Boolean> = MutableLiveData(false)
        var rewardFailed: Boolean = false
        private var rewardAd: RewardedAd? = null
        fun loadRewardedAd(id: String, activity: Activity) {
            Log.e("TAG", "loadRewardedAd: Start Loading")
            rewardAdLoaded.value = false
            val adRequest = AdRequest.Builder().build()
            RewardedAd.load(
                activity, id,
                adRequest,
                object : RewardedAdLoadCallback() {
                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        rewardFailed = true
                        rewardAdLoaded.value = true
                        Log.e("TAG", "onAdFailedToLoad: $loadAdError")
                    }

                    override fun onAdLoaded(rewardedAd: RewardedAd) {
                        Log.e("TAG", "onAdLoaded: Loaded", )
                        rewardAd = rewardedAd
                        rewardAdLoaded.value = true
                    }
                },
            )
        }

        fun showRewardedAd(activity: Activity) {
            Log.e("TAG", "showRewardedAd: ${rewardAd==null}", )
            rewardAd?.fullScreenContentCallback = object :
                FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() {

                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    val newIntent = Intent(activity, HomeScreen::class.java)
                    activity.startActivity(newIntent)
                    activity.finish()
                }

                override fun onAdDismissedFullScreenContent() {
                    val newIntent = Intent(activity, HomeScreen::class.java)
                    activity.startActivity(newIntent)
                    activity.finish()
                }
            }
            rewardAd?.show(activity) {

            }
        }

        fun onBoardingNative(id: String, activity: Activity) {
            if (id.isNotEmpty()) {
                val adLoader = AdLoader.Builder(activity, id)
                    .forNativeAd { ad: NativeAd ->
                        nativeAd = ad
                    }
                    .withAdListener(object : AdListener() {
                        override fun onAdFailedToLoad(adError: LoadAdError) {
                            Log.e("TAG OnBoardingNative", "onAdFailedToLoad: $adError")
                        }
                    })
                    .withNativeAdOptions(
                        NativeAdOptions.Builder().build()
                    ).build()
                adLoader.loadAd(AdRequest.Builder().build())

            }
        }

        fun loadBanner(id: String, activity: Activity): AdView {
            val adView = AdView(activity);
            adView.adUnitId = id

            val displayMetrics = activity.resources.displayMetrics

            val adWidthPixels =
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val windowMetrics: WindowMetrics =
                        activity.windowManager.currentWindowMetrics
                    windowMetrics.bounds.width()
                } else {
                    displayMetrics.widthPixels
                }
            val density = displayMetrics.density
            val adWidth = (adWidthPixels / density).toInt()
            val adSize: AdSize =
                AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, adWidth)


            adView.setAdSize(adSize)

            val extras = Bundle()
            extras.putString("collapsible", "bottom")
            val adRequest = AdRequest.Builder()
                .addNetworkExtrasBundle(AdMobAdapter::class.java, extras)
                .build()
            adView.loadAd(adRequest)

            return adView
        }

        var calculatorNativeAd: NativeAd? = null
        fun loadNativeAd(id: String, activity: Activity) {
            val adLoader = AdLoader.Builder(activity, id)
                .forNativeAd { nativeAd ->
                    calculatorNativeAd = nativeAd
                }
                .withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(adError: LoadAdError) {
                        Log.e("TAG Load Calculator", "onAdFailedToLoad: $adError")
                    }
                })
                .withNativeAdOptions(
                    NativeAdOptions.Builder()
                        .build()
                )
                .build()
            adLoader.loadAds(AdRequest.Builder().build(), 3)
        }


    }
}