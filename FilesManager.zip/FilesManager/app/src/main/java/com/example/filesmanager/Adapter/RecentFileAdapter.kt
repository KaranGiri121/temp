package com.example.filesmanager.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.filesmanager.DB.RecentFileDB
import com.example.filesmanager.DB.RecentFileEntity
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.Utils.Helper.FileTypes
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.util.Date

class RecentFileAdapter(val context: Context, val arr: List<RecentFileEntity>) :
    RecyclerView.Adapter<RecentFileAdapter.ViewHolder>() {
    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val fileLayout = itemView.findViewById<LinearLayout>(R.id.ll_recent)
        val fileIcon = itemView.findViewById<ImageView>(R.id.iv_recent_icon)
        val fileName = itemView.findViewById<TextView>(R.id.tv_recent_name)
        val fileSize = itemView.findViewById<TextView>(R.id.tv_recent_size)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.recent_file_layout, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = arr.size

    override fun onBindViewHolder(holder: ViewHolder, pos: Int) {
        holder.fileName.text = arr[holder.absoluteAdapterPosition].fileName
        holder.fileSize.text = Helper.formatDate(arr[holder.absoluteAdapterPosition].openTime)
        val extension: FileTypes? =
            Helper.fromMimeType(arr[holder.absoluteAdapterPosition].fileType)
        Helper.populateIcon(
            context,
            extension,
            arr[holder.absoluteAdapterPosition].filePath,
            arr[holder.absoluteAdapterPosition].fileId,
            holder.fileIcon
        )
        holder.fileLayout.setOnClickListener {
            when (extension) {
                FileTypes.APK -> {
                    Helper.launchApkIntent(context, arr[holder.absoluteAdapterPosition].filePath)
                }

                FileTypes.AUDIO -> {
                    //Todo
                }

                FileTypes.VIDEO -> {
                    //Todo
                }

                FileTypes.PDF -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("pdf").toString()
                    )
                }

                FileTypes.TXT -> {
                    Helper.launchDocSupportedIntent(
                        context,
                        arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("txt").toString()
                    )
                }

                FileTypes.WORD -> {
                    Helper.launchDocSupportedIntent(
                        context,
                        arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("doc").toString()
                    )
                }

                FileTypes.PPT -> {
                    Helper.launchDocSupportedIntent(
                        context,
                        arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("ppt").toString()
                    )
                }

                FileTypes.EXCEL -> {
                    Helper.launchDocSupportedIntent(
                        context,
                        arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("xls").toString()
                    )
                }

                FileTypes.IMAGE -> {
                    //Todo
                }

                FileTypes.WORDX -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("docx").toString()
                    )
                }

                FileTypes.PPTX -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("pptx").toString()
                    )
                }

                FileTypes.EXCELX -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("xlsx").toString()
                    )
                }

                FileTypes.ZIP -> {
                    Helper.launchDocSupportedIntent(
                        context,
                        arr[holder.absoluteAdapterPosition].filePath,
                        arr[holder.absoluteAdapterPosition].fileType
                    )
                }

                else -> {
                    //Todo
//                    Helper.launchDocSupportedIntent(
//                        context, arr[holder.absoluteAdapterPosition].filePath,
//                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("pdf").toString()
//                    )
                }
            }
            CoroutineScope(Dispatchers.IO).launch {
                RecentFileDB.getInstance(context).getRecentDao().insertRecent(
                    RecentFileEntity(
                        fileId = arr[holder.absoluteAdapterPosition].id,
                        fileName = arr[holder.absoluteAdapterPosition].fileName,
                        filePath = arr[holder.absoluteAdapterPosition].filePath,
                        openTime = Date().time,
                        fileType = arr[holder.absoluteAdapterPosition].fileType
                    )
                )
            }
        }

    }
}