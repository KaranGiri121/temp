package com.example.filesmanager.Model

data class MusicModel(
    val id: Long,
    val fileName: String,
    val fileSize: Long,
    val duration: Long,
    val posterUri: Long,
    val artistName: String
){
    constructor(): this(0,"",0,0,0,"")
}
