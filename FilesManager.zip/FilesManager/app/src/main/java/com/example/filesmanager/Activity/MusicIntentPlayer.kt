package com.example.filesmanager.Activity

import android.media.MediaPlayer
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.databinding.ActivityMusicIntentPlayerBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class MusicIntentPlayer : AppCompatActivity() {
    private lateinit var binding: ActivityMusicIntentPlayerBinding
    private lateinit var mediaPlayer: MediaPlayer
    private var seekHandler: Job? = null
    val isPlaying: MutableStateFlow<Boolean> = MutableStateFlow(false)
    val isLooping: MutableStateFlow<Boolean> = MutableStateFlow(false)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMusicIntentPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        mediaPlayer = MediaPlayer()
        val uri = intent.data!!


        mediaPlayer.setDataSource(this, uri)
        mediaPlayer.prepare()
        mediaPlayer.setOnPreparedListener {
            mediaPlayer.start()
            isPlaying.update {
                true
            }
            binding.tvMusicTotalDuration.text = Helper.getDuration(mediaPlayer.duration.toLong())
            seekHandler = CoroutineScope(Dispatchers.IO).launch {
                var duration = 0
                do {
                    duration = mediaPlayer.currentPosition
                    binding.tvMusicProgressDuration.text = Helper.getDuration(duration.toLong())
                    delay(1000)
                } while (duration < mediaPlayer.duration)
            }
        }

        mediaPlayer.setOnCompletionListener {
            if(isLooping.value){
                mediaPlayer.setDataSource(this, uri)
                mediaPlayer.prepare()
            }
        }

        lifecycleScope.launch {
            isPlaying.collectLatest {
                if (it) {
                    binding.ivMusicPlay.setImageDrawable(
                        AppCompatResources.getDrawable(
                            this@MusicIntentPlayer,
                            R.drawable.ic_play_btn
                        )
                    )
                } else {
                    binding.ivMusicPlay.setImageDrawable(
                        AppCompatResources.getDrawable(
                            this@MusicIntentPlayer,
                            R.drawable.ic_pause_btn
                        )
                    )
                }
            }
        }

        binding.ivMusicRepeat.setOnClickListener {
            isLooping.value=!isLooping.value
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer.release()
    }
}