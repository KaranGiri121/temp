package com.example.filesmanager.ViewModel

import android.content.ContentResolver
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import android.webkit.MimeTypeMap
import com.example.filesmanager.Model.DocsModel

class DocsRepo {

    var TAG = "SystemFileViewModel"


    fun getAllDoc(contentResolver: ContentResolver) : List<DocsModel>{
        val allFiles: MutableList<DocsModel> = mutableListOf()
        val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Files.getContentUri("external")
        }

        val extension = arrayOf(
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("pdf"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("doc"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("docx"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("xlsx"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("txt"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("ppt"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("pptx"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("apk"),
        )
        val selectionArgs = extension.filterNotNull().toTypedArray()
        val args = selectionArgs.joinToString{"?"}

        val selection =
            MediaStore.Files.FileColumns.MIME_TYPE + " IN (" + args + ")"
        val projections =
            arrayOf(
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DATA,
                MediaStore.Files.FileColumns.DISPLAY_NAME,
                MediaStore.Files.FileColumns.DATE_MODIFIED,
                MediaStore.Files.FileColumns.MIME_TYPE,
                MediaStore.Files.FileColumns.SIZE
            )
        val pointer = contentResolver.query(uri, projections, selection, selectionArgs, null)

        if (pointer != null) {
        Log.e(TAG, "getAllDoc: ${pointer.count}", )
            while (pointer.moveToNext()) {
                val id = pointer.getLong(0)
                val filePath = pointer.getString(1)
                val fileName = pointer.getString(2)
                val fileType = pointer.getString(4)
                val fileSize = pointer.getLong(5)
                allFiles.add(DocsModel(id, filePath, fileName, fileType,fileSize))
            }
        }
        return allFiles
    }
}