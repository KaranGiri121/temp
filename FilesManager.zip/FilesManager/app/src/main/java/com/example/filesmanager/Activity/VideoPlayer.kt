package com.example.filesmanager.Activity

import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.SurfaceHolder
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import com.example.filesmanager.Layout.CustomMediaController
import com.example.filesmanager.databinding.ActivityVideoPlayerBinding

class VideoPlayer : AppCompatActivity() {


    private lateinit var binding: ActivityVideoPlayerBinding
    var mediaController: CustomMediaController? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val landscape = intent.getBooleanExtra("landscape", false)
        if (landscape)
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE

        binding = ActivityVideoPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.videoSurfaceContainer.setOnClickListener {

        }

        binding.videoSurface.holder.addCallback(
            object : SurfaceHolder.Callback {
                override fun surfaceCreated(holder: SurfaceHolder) {
                    mediaController?.mediaPlayer?.setDisplay(holder)
                    mediaController?.mediaPlayer?.prepare()
                    mediaController?.setAnchorView(binding.videoSurfaceContainer)
                }

                override fun surfaceChanged(
                    holder: SurfaceHolder,
                    format: Int,
                    width: Int,
                    height: Int
                ) {

                }

                override fun surfaceDestroyed(holder: SurfaceHolder) {

                }
            },
        )


        mediaController = CustomMediaController(this)
        mediaController?.initiateMediaPlayer()

    }

    override fun onDestroy() {
        mediaController?.seekHandler?.cancel()
        mediaController?.mediaPlayer?.release()
        super.onDestroy()
    }


    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)

        val videoWidth = mediaController?.mediaPlayer?.videoWidth ?: 0
        val videoHeight = mediaController?.mediaPlayer?.videoHeight ?: 0

        // Get the current screen orientation
        val screenOrientation = newConfig.orientation

        val aspectRatio = if (videoWidth != 0 && videoHeight != 0) {
            videoWidth.toFloat() / videoHeight.toFloat()
        } else {
            1f
        }

        val params = binding.videoSurface.layoutParams as FrameLayout.LayoutParams

        if (screenOrientation == Configuration.ORIENTATION_LANDSCAPE) {
            if (videoWidth < videoHeight) {
                Log.e("TAG", "onConfigurationChanged: ", )
                params.width = videoWidth
                params.height = FrameLayout.LayoutParams.MATCH_PARENT
                params.gravity = Gravity.CENTER
            } else {
                params.width = FrameLayout.LayoutParams.MATCH_PARENT
                params.height = (params.width / aspectRatio).toInt()
            }
        } else {
            params.width = FrameLayout.LayoutParams.MATCH_PARENT
            params.height = (params.width / aspectRatio).toInt()
        }

        binding.videoSurface.layoutParams = params

    }
}