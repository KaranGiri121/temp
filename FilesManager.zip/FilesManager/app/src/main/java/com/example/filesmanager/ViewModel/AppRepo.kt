package com.example.filesmanager.ViewModel

import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.Intent
import android.os.storage.StorageManager
import android.util.Log
import androidx.appcompat.app.AppCompatActivity.STORAGE_STATS_SERVICE
import com.example.filesmanager.Model.AppModel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

class AppRepo {
    private final val TAG = "AppRepo"
    suspend fun getAllAppInfo(context: Context):List<AppModel> {
        val allInstalledApp: MutableList<AppModel> = mutableListOf()
        coroutineScope {

            val mainIntent = Intent(Intent.ACTION_MAIN, null)
            mainIntent.addCategory(Intent.CATEGORY_LAUNCHER)
            val pkgAppsList = context.packageManager.queryIntentActivities(mainIntent, 0)
            for (data in pkgAppsList) {
                var appDataSize: Long = 0
                launch {
                    val uid = context.packageManager.getPackageInfo(data.activityInfo.packageName, 0)
                    val storageStatsManager =
                        context.getSystemService(STORAGE_STATS_SERVICE) as StorageStatsManager

                    try {
                        val result= launch{
                            val storageStats =
                                storageStatsManager.queryStatsForUid(
                                    StorageManager.UUID_DEFAULT,
                                    uid.applicationInfo.uid
                                )
                            appDataSize = storageStats.appBytes
                            allInstalledApp.add(
                                AppModel(
                                    context.packageManager.getApplicationLabel(
                                        context.packageManager.getApplicationInfo(
                                            data.activityInfo.packageName,
                                            0
                                        ),
                                    ).toString(), data.activityInfo.packageName,
                                    appDataSize
                                )
                            )
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "onCreate: ", e)
                    }


                }
            }

        }
            return allInstalledApp
    }
}