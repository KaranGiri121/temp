package com.example.filesmanager.Model

data class DocsModel(val id: Long, val filePath: String, val fileName: String, val fileType: String,val fileSize:Long)
