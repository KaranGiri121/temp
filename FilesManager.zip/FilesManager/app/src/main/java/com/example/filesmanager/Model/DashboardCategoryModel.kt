package com.example.filesmanager.Model

data class DashboardCategoryModel(val icon:Int,val iconName:String,val colorString:String)
