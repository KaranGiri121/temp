package com.example.filesmanager.Adapter

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.filesmanager.Activity.ImageScreen
import com.example.filesmanager.DB.RecentFileDB
import com.example.filesmanager.DB.RecentFileEntity
import com.example.filesmanager.Model.ImageModel
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Date

class ImageListAdapter(val context: Context, val arr:List<ImageModel>): RecyclerView.Adapter<ImageListAdapter.ImageListViewHolder>() {
    class ImageListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView = itemView.findViewById<ImageView>(R.id.iv_imageList_thumbnail)

    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): ImageListViewHolder {
        val view = LayoutInflater.from(p0.context).inflate(R.layout.image_list_layout,p0,false)
        return ImageListViewHolder(view)
    }

    override fun getItemCount(): Int {
        return arr.size
    }

    override fun onBindViewHolder(holder: ImageListViewHolder, position: Int) {
        Glide.with(holder.imageView.context).load(ContentUris.withAppendedId(Helper.imageUri,arr[position].id)).into(holder.imageView)

        holder.imageView.setOnClickListener{
            Helper.imagePosition = position
            val newIntent = Intent(context,ImageScreen::class.java)
            CoroutineScope(Dispatchers.IO).launch {
                RecentFileDB.getInstance(context).getRecentDao()
                    .insertRecent(
                        RecentFileEntity(
                            fileId = arr[position].id,
                            fileName = arr[position].fileName,
                            filePath = arr[position].filePath,
                            fileType = arr[position].fileType,
                            openTime = Date().time
                        )
                    )
            }
            context.startActivity(newIntent)
        }
    }
}