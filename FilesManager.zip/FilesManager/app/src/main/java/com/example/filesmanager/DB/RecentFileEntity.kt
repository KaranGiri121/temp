package com.example.filesmanager.DB

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "RecentFileEntity")
data class RecentFileEntity(
    @PrimaryKey(autoGenerate = true) val id:Long = 0,
    val fileId: Long,
    val fileName:String,
    val filePath:String,
    val fileType:String,
    val openTime:Long,
)