package com.example.filesmanager.Adapter

import android.app.Activity
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.MutableLiveData
import com.example.filesmanager.Model.QuickFileModel
import com.example.filesmanager.R
import com.example.filesmanager.Utils.CommonViewModel
import com.example.filesmanager.Utils.Helper
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.checkbox.MaterialCheckBox.STATE_CHECKED
import com.google.android.material.checkbox.MaterialCheckBox.STATE_INDETERMINATE
import com.google.android.material.checkbox.MaterialCheckBox.STATE_UNCHECKED


class QuickFilesAdapter(
    context: Activity,
    private val arr: MutableList<QuickFileModel>,
    private val deleteFile: MutableLiveData<MutableList<QuickFileModel>>,
    private val filesSize: MutableLiveData<Long>,
    val checkBox: MaterialCheckBox
) : ArrayAdapter<QuickFileModel>(context, 0, arr) {

    private val viewMode = CommonViewModel.cleanViewModel

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view = convertView

        if (view == null) {
            view = LayoutInflater.from(context)
                .inflate(R.layout.quick_clean_file_layout, parent, false)
        }

        val file: QuickFileModel = getItem(position)!!

        val fileIcon = view!!.findViewById<ImageView>(R.id.iv_quickFile_icon)
        val fileName = view.findViewById<TextView>(R.id.tv_quickFile_name)
        val fileSize = view.findViewById<TextView>(R.id.tv_quickFile_size)
        val fileLayout = view.findViewById<LinearLayout>(R.id.ll_quick_clean)
        val fileDelete = view.findViewById<CheckBox>(R.id.cb_quickFile_delete)



        deleteFile.observe(context as LifecycleOwner) {
            fileDelete.isChecked = it.contains(arr[position])
        }

        fileDelete.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                if (!deleteFile.value?.contains(arr[position])!!) {
                    deleteFile.value?.add(arr[position])
                    filesSize.value = filesSize.value?.plus(arr[position].fileSize)
                }
            } else {
                if (deleteFile.value?.contains(arr[position])!!) {
                    deleteFile.value?.remove(arr[position])
                    filesSize.value = filesSize.value?.minus(arr[position].fileSize)
                }
            }

            if (deleteFile.value?.isEmpty() ?: true) {
                checkBox.checkedState = STATE_UNCHECKED
            } else if (deleteFile.value?.size != arr.size) {
                checkBox.checkedState = STATE_INDETERMINATE;
            } else {
                checkBox.checkedState = STATE_CHECKED
            }
        }

        Helper.populateIcon(
            context,
            Helper.fromMimeType(arr[position].fileType),
            arr[position].filePath,
            arr[position].id,
            fileIcon
        )

        fileName.text = file.fileName
        fileSize.text = Helper.formatSize(file.fileSize)

        return view
    }

    fun selectAll() {
        Log.e("TAG", "selectAll: ", )
        val newArr: MutableList<QuickFileModel> = mutableListOf()
        newArr.addAll(arr)
        deleteFile.value = newArr

        var size:Long = 0
        for(i in newArr.indices){
            size+=newArr[i].fileSize
        }

        filesSize.value = size

    }

    fun clearAll() {
        deleteFile.value = mutableListOf()
        filesSize.value = 0
    }

    fun update() {
        notifyDataSetChanged()
    }
}