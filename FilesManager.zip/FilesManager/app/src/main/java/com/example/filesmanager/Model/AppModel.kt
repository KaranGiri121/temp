package com.example.filesmanager.Model

data class AppModel(val appName:String,val packageName:String,val occupiedSize:Long)