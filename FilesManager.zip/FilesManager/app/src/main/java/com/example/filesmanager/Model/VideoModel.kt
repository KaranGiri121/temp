package com.example.filesmanager.Model

data class VideoModel(val id:Long,val fileName:String,val filePath:String,val duration: Long,val fileSize:Long,val width:Long,val height:Long,val fileType:String)
