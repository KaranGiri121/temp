package com.example.filesmanager.Utils

import com.example.filesmanager.Model.MusicModel
import com.example.filesmanager.Model.QuickFileModel

class AppConstant {
    enum class MediaState(val state: String?) {
        START_NEW("start_new"), PLAY("Play"), PAUSE("Pause"), NEXT("Next"), PREV("Previous");

        companion object {
            fun fromState(state: String): MediaState? {
                return entries.find { it.state == state }
            }
        }
    }

    enum class LoopState() {
        DISABLE, SELF, TRACK
    }

    companion object {
        var storeFileList: List<QuickFileModel> = listOf()
        var duplicateFileList: Map<String, List<QuickFileModel>> = mapOf()
        var musicPlayList: List<MusicModel> = listOf()
        var musicIndex: Int = 0

    }


//    companion object {
//        private final val TAG = "AppConstant"
//
//        private lateinit var applicationContext: Context
//        var quickScanDone = false
//        val singleFile: HashMap<String, QuickFileModel> = hashMapOf()
//        val largeFile: MutableLiveData<List<QuickFileModel>> = MutableLiveData()
//        var largeFileSize: Long = 0
//
//        val duplicateFile: MutableLiveData<HashMap<String, MutableList<QuickFileModel>>> = MutableLiveData()
//        var duplicateFileSize: Long = 0
//        var duplicateFileCount: Long = 0
//
//        val installedApk : MutableLiveData<List<QuickFileModel>> = MutableLiveData()
//        var installedApkSize: Long = 0
//
//        val trashFile : MutableLiveData<List<QuickFileModel>> = MutableLiveData()
//        var trashFileSize : Long = 0
//
//        val deleteFile : MutableList<QuickFileModel> = mutableListOf()
//        val deletedFileLiveData: MutableLiveData<MutableList<QuickFileModel>> = MutableLiveData(deleteFile)
//        var deleteFileSize : Long = 0
//
//
//        fun quickScan(contentResolver: ContentResolver) {
//            quickScanDone = true
//            searchForHiddenFile(contentResolver)
//
//            val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
//                MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
//            } else {
//                MediaStore.Files.getContentUri("external")
//            }
//            val extension = arrayOf(
//                MimeTypeMap.getSingleton().getMimeTypeFromExtension("pdf"),
//                MimeTypeMap.getSingleton().getMimeTypeFromExtension("doc"),
//                MimeTypeMap.getSingleton().getMimeTypeFromExtension("docx"),
//                MimeTypeMap.getSingleton().getMimeTypeFromExtension("xlsx"),
//                MimeTypeMap.getSingleton().getMimeTypeFromExtension("txt"),
//                MimeTypeMap.getSingleton().getMimeTypeFromExtension("ppt"),
//                MimeTypeMap.getSingleton().getMimeTypeFromExtension("pptx"),
//                MimeTypeMap.getSingleton().getMimeTypeFromExtension("png"),
//                MimeTypeMap.getSingleton().getMimeTypeFromExtension("jpg"),
//                MimeTypeMap.getSingleton().getMimeTypeFromExtension("jpeg"),
//                MimeTypeMap.getSingleton().getMimeTypeFromExtension("gif"),
//                MimeTypeMap.getSingleton().getMimeTypeFromExtension("mp4"),
//                MimeTypeMap.getSingleton().getMimeTypeFromExtension("mkv"),
//                MimeTypeMap.getSingleton().getMimeTypeFromExtension("avi"),
//                MimeTypeMap.getSingleton().getMimeTypeFromExtension("apk"),
//                MimeTypeMap.getSingleton().getMimeTypeFromExtension("mp3"),
//            )
//            val selectionArgs = extension
//            val args = selectionArgs.joinToString { "?" }
//
//            val selection = MediaStore.Files.FileColumns.MIME_TYPE + " IN (" + args + ")"
//            val projections =
//                arrayOf(
//                    MediaStore.Files.FileColumns._ID,
//                    MediaStore.Files.FileColumns.DATA,
//                    MediaStore.Files.FileColumns.MIME_TYPE,
//                    MediaStore.Files.FileColumns.SIZE,
//                    MediaStore.Files.FileColumns.DISPLAY_NAME,
//                    )
//
//
//            val pointer = contentResolver.query(
//                uri,
//                projections,
//                selection,
//                selectionArgs,
//                MediaStore.Files.FileColumns.SIZE + " DESC"
//            )
//            val allFileList: MutableList<QuickFileModel> = mutableListOf()
//            val allApkList: MutableList<QuickFileModel> = mutableListOf()
//            if (pointer != null) {
//                while (pointer.moveToNext()) {
//                    val fileData = pointer.getString(1)
//                    val fileId = pointer.getLong(0)
//                    val fileType = pointer.getString(2)
//                    val fileSize = pointer.getLong(3)
//                    val fileName = pointer.getString(4)
//                    val filePath = pointer.getString(1)
//                    val file =QuickFileModel(fileId,fileName,filePath, fileSize,fileData,fileType)
//                    allFileList.add(file)
//                    if(MimeTypeMap.getSingleton().getMimeTypeFromExtension("apk") == fileType){
//                        allApkList.add(file)
//                    }
//                }
//            }
//
//            getLargeFile(allFileList)
//            getDuplicate(allFileList)
//            getInstalledApk(allApkList)
//            allApkList.clear()
//        }
//
//        private fun getLargeFile(allFileList: List<QuickFileModel>) {
//            val files: MutableList<QuickFileModel> = mutableListOf()
//            CoroutineScope(Dispatchers.IO).launch {
//                repeat(allFileList.size, {
//                    val fileSize= allFileList[it].fileSize
//                    if ( fileSize> 1024 * 1024 * 20) {
//                        files.add(allFileList[it])
//                        largeFileSize += fileSize
//                    }
//                })
//                largeFile.postValue(files)
//            }
//        }
//
//        private fun getDuplicate(allFileList: List<QuickFileModel>) {
//            val duplicate: HashMap<String, MutableList<QuickFileModel>> = hashMapOf()
//            CoroutineScope(Dispatchers.IO).launch {
//                repeat(
//                    allFileList.size,
//                    {
//                        try{
//                            val md5Value = File(allFileList[it].fileData).calculateMD5()
//                            if (!singleFile.containsKey(md5Value)) {
//                                singleFile[md5Value] = allFileList[it]
//                            } else {
//                                if (duplicate[md5Value] == null) {
//                                    duplicate[md5Value] = mutableListOf(allFileList[it], singleFile[md5Value]!!)
//                                } else {
//                                    duplicate[md5Value]!!.add(allFileList[it])
//                                }
//                                duplicateFileSize+=allFileList[it].fileSize
//                                duplicateFileCount += 1
//                            }
//                        }catch (e:Exception){
//                            Log.e(TAG, "getDuplicate: ${allFileList[it].fileData}", )
//                        }
//                    },
//                )
//                duplicateFile.postValue(duplicate)
//            }
//        }
//
//        private fun File.calculateMD5(): String {
//            val buffer = ByteArray(1024 * 1024)
//            val md = MessageDigest.getInstance("MD5")
//            FileInputStream(this).use { fis ->
//                var bytesRead: Int
//                while (fis.read(buffer).also { bytesRead = it } != -1) {
//                    md.update(buffer, 0, bytesRead)
//                }
//            }
//            return md.digest().joinToString("") { "%02x".format(it) }
//        }
//
//        private fun getInstalledApk(allApkList: List<QuickFileModel>){
//            val mainIntent = Intent(Intent.ACTION_MAIN, null)
//            mainIntent.addCategory(Intent.CATEGORY_LAUNCHER)
//
//            CoroutineScope(Dispatchers.IO).launch {
//                val pkgAppsList = applicationContext.packageManager.queryIntentActivities(mainIntent, 0)
//                val allInstalledApp: MutableList<String> = mutableListOf()
//                for (data in pkgAppsList) {
//                    allInstalledApp.add(data.activityInfo.packageName)
//                }
//
//                val installApkFound : MutableList<QuickFileModel> = mutableListOf()
//                for(i in allApkList){
//                    val packageInfo = applicationContext.packageManager.getPackageArchiveInfo(i.filePath,0)
//
//                    if(allInstalledApp.contains(packageInfo?.packageName)){
//                        installedApkSize+=i.fileSize
//                        installApkFound.add(i)
//                    }
//                }
//                installedApk.postValue(installApkFound)
//            }
//
//        }
//
//        private fun searchForHiddenFile(contentResolver: ContentResolver){
//            val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
//                MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
//            } else {
//                MediaStore.Files.getContentUri("external")
//            }
//
//            val projections =
//                arrayOf(
//                    MediaStore.Files.FileColumns._ID,
//                    MediaStore.Files.FileColumns.DATA,
//                    MediaStore.Files.FileColumns.MIME_TYPE,
//                    MediaStore.Files.FileColumns.SIZE,
//                    MediaStore.Files.FileColumns.DISPLAY_NAME,
//                    MediaStore.Files.FileColumns.IS_TRASHED
//                )
//            val bundle = Bundle()
//            bundle.putInt("android:query-arg-match-trashed", 1)
//            bundle.putString(
//                "android:query-arg-sql-selection",
//                "${MediaStore.MediaColumns.IS_TRASHED} = 1"
//            )
//            bundle.putString(
//                "android:query-arg-sql-sort-order",
//                "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
//            )
//            val pointer = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                contentResolver.query(
//                    MediaStore.Files.getContentUri("external"),
//                    projections,
//                    bundle, null
//
//                )
//            } else {
//                contentResolver.query(
//                    uri,
//                    projections,
//                    null,null,
//                    null
//                )
//            }
//
//
//            val trashFile :MutableList<QuickFileModel> = mutableListOf()
//            if (pointer != null) {
//                while (pointer.moveToNext()) {
//                    val fileData = pointer.getString(1)
//                    val fileId = pointer.getLong(0)
//                    val fileType = pointer.getString(2)
//                    val fileSize = pointer.getLong(3)
//                    val fileName = pointer.getString(4)
//                    val filePath = pointer.getString(1)
//                    trashFile.add(QuickFileModel(fileId,fileName, filePath, fileSize, fileData, fileType))
//                    trashFileSize+=fileSize
//                }
//            }
//
//            this.trashFile.value = trashFile
//        }
//    }
}