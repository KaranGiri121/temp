package com.example.filesmanager.Utils

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import android.webkit.MimeTypeMap
import android.widget.ImageView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.startActivity
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.IconCompat
import com.bumptech.glide.Glide
import com.example.filesmanager.Model.ImageModel
import com.example.filesmanager.Model.QuickFileModel
import com.example.filesmanager.Model.VideoModel
import com.example.filesmanager.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.text.DecimalFormat
import java.util.Calendar
import java.util.Date


class Helper {
    enum class FileTypes(val mimeTypes: List<String?>) {
        APK(
            listOf(
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("apk")
            )
        ),
        AUDIO(
            listOf(
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("mp3")
            )
        ),
        VIDEO(
            listOf(
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("mp4"),
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("mkv"),
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("avi"),
            )
        ),
        PDF(
            listOf(
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("pdf"),
            )
        ),
        TXT(
            listOf(
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("txt"),
            )
        ),
        WORD(
            listOf(
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("doc"),
            ),
        ),
        WORDX(
            listOf(
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("docx"),
            )
        ),
        PPT(
            listOf(
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("ppt"),
            ),
        ),
        PPTX(
            listOf(
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("pptx"),
            )
        ),
        EXCEL(
            listOf(
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("xls"),
            ),
        ),
        EXCELX(
            listOf(
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("xlsx"),

                )
        ),
        IMAGE(
            listOf(
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("jpg"),
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("jpeg"),
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("png"),
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("gif"),
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("webp"),
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("heic"),
            )
        ),
        ZIP(
            listOf(
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("zip"),
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("rar"),
                MimeTypeMap.getSingleton().getMimeTypeFromExtension("7z"),

            )
        )
    }

    companion object {
        private val iPath: File = Environment.getDataDirectory()
        private val iStat = StatFs(iPath.path)
        private val iBlockSize = iStat.blockSizeLong
        private val iAvailableBlocks = iStat.availableBlocksLong
        private val iTotalBlocks = iStat.blockCountLong
        val iAvailableSpace = (iAvailableBlocks * iBlockSize)
        val iTotalSpace = (iTotalBlocks * iBlockSize)
        val iUsedSpace = (iTotalBlocks * iBlockSize) - (iAvailableBlocks * iBlockSize)


        var videoFolder: List<VideoModel> = listOf()
        var videoPosition: Int = 0

        var imagePosition: Int = 0
        var imageFolder: List<ImageModel> = listOf()
        val videoUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val imageUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val musicUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI


        fun getDuration(duration: Long): String {
            var second: Long = duration / 1000
            var minute: Long = 0
            var hour: Long = 0
            if (second >= 60) {
                minute = second / 60
                second -= (minute * 60)
                if (minute >= 60) {
                    hour = minute / 60
                    minute -= (hour * 60)
                }
            }



            if (minute.toInt() == 0) {
                if (second.toInt() < 10) {
                    return "00:0$second"
                } else {
                    return "00:$second"
                }
            } else {
                if (hour.toInt() == 0) {
                    if (minute.toInt() < 10) {
                        if (second.toInt() < 10) {
                            return "0$minute:0$second"
                        } else {
                            return "0$minute:$second"
                        }
                    } else {
                        if (second.toInt() < 10) {
                            return "$minute:0$second"
                        } else {
                            return "$minute:$second"
                        }
                    }
                } else {
                    if (hour.toInt() < 10) {
                        if (minute.toInt() < 10) {
                            if (second.toInt() < 10) {
                                return "0$hour:0$minute:0$second"
                            } else {
                                return "0$hour:0$minute:$second"
                            }
                        } else {
                            if (second.toInt() < 10) {
                                return "0$hour:$minute:0$second"
                            } else {
                                return "0$hour:$minute:$second"
                            }
                        }
                    } else {
                        if (minute.toInt() < 10) {
                            if (second.toInt() < 10) {
                                return "$hour:0$minute:0$second"
                            } else {
                                return "$hour:0$minute:$second"
                            }
                        } else {
                            if (second.toInt() < 10) {
                                return "$hour:$minute:0$second"
                            } else {
                                return "$hour:$minute:$second"
                            }
                        }
                    }
                }
            }
        }

        fun formatDate(time: Long): String {
            val dateObject = Date(time)
            val calendarInstance = Calendar.getInstance()
            calendarInstance.time = dateObject
            val hour = calendarInstance.get(Calendar.HOUR)
            val minute = calendarInstance.get(Calendar.MINUTE)
            val ampm = if (calendarInstance.get(Calendar.AM_PM) == 0) "AM " else "PM "
            val date = calendarInstance.get(Calendar.DATE)
            val month = calendarInstance.get(Calendar.MONTH)
            val year = calendarInstance.get(Calendar.YEAR)
            return "$date-${month + 1}-$year"
        }

        fun formatSize(size: Long): String {
            if (size <= 0) {
                return "0 B"
            }

            val units = arrayOf("B", "KB", "MB", "GB", "TB")
            var calculatedSize = size.toDouble()
            var unitIndex = 0

            while (calculatedSize >= 1024.0 && unitIndex < units.size - 1) {
                calculatedSize /= 1024.0
                unitIndex++
            }

            val df = DecimalFormat("#.##") // Format to two decimal places
            return "${df.format(calculatedSize)} ${units[unitIndex]}"
        }

        fun getTintedIcon(context: Context, id: Int): IconCompat {
            val originalBitmap = BitmapFactory.decodeResource(context.resources, id)
            Log.e("TAG", "getTintedIcon: $originalBitmap")
            val tintedBitmap = originalBitmap.copy(Bitmap.Config.ARGB_8888, true)

            val paint = Paint()
            paint.colorFilter = PorterDuffColorFilter(
                ContextCompat.getColor(context, R.color.black),
                PorterDuff.Mode.SRC_IN
            )

            val canvas = Canvas(tintedBitmap)
            canvas.drawBitmap(tintedBitmap, 0f, 0f, paint)

            val icon = IconCompat.createWithBitmap(tintedBitmap)
            return icon
        }

        fun storagePermission(context: Context, activity: Activity): Boolean {
            val permissionStatus = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Environment.isExternalStorageManager()
            } else {
                val write =
                    ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    )
                val read =
                    ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.READ_EXTERNAL_STORAGE
                    )

                read == PackageManager.PERMISSION_GRANTED && write == PackageManager.PERMISSION_GRANTED
            }

            if (!permissionStatus) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    var result = false
                    try {
                        val intent = Intent()
                        intent.setAction(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                        val uri = Uri.fromParts("package", context.packageName, null)

                        intent.setData(uri)
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        val intent = Intent()
                        intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                        context.startActivity(intent)
                    }
                } else {

                    ActivityCompat.requestPermissions(
                        activity,
                        arrayOf(
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                        ),
                        101
                    )
                }
                return false
            } else {
                return true
            }
        }

        fun fromMimeType(mimeType: String?): FileTypes? {
            return FileTypes.entries.find { it.mimeTypes.contains(mimeType) }
        }

        fun populateIcon(
            context: Context,
            fileType: FileTypes?,
            filePath: String,
            id: Long,
            fileIcon: ImageView,
        ) {
            when (fileType) {
                FileTypes.APK -> {
                    val iconData =
                        context.packageManager.getPackageArchiveInfo(
                            filePath,
                            0
                        )?.applicationInfo?.let {
                            it.sourceDir = filePath
                            it.publicSourceDir = filePath
                            it.loadIcon(context.packageManager)
                        }
                            ?: R.drawable.ic_extension_apk
                    Glide.with(context).load(iconData).into(fileIcon)
                }

                FileTypes.AUDIO -> {
                    Glide.with(context)
                        .load(Uri.parse("content://media/external/audio/albumart/$id"))
                        .placeholder(R.drawable.ic_music_icon)
                        .into(fileIcon)
                }

                FileTypes.VIDEO -> {
                    Glide.with(context).load(ContentUris.withAppendedId(videoUri, id))
                        .into(fileIcon)
                }

                FileTypes.PDF -> {
                    Glide.with(context).load(R.drawable.ic_extension_pdf)
                        .into(fileIcon)
                }

                FileTypes.TXT -> {
                    Glide.with(context).load(R.drawable.ic_extension_txt)
                        .into(fileIcon)
                }

                FileTypes.WORD -> {
                    Glide.with(context).load(R.drawable.ic_extension_doc)
                        .into(fileIcon)
                }

                FileTypes.PPT -> {
                    Glide.with(context).load(R.drawable.ic_extension_ppt)
                        .into(fileIcon)
                }

                FileTypes.EXCEL -> {
                    Glide.with(context).load(R.drawable.ic_extension_excel)
                        .into(fileIcon)
                }

                FileTypes.IMAGE -> {
                    Log.e("TAG", "populateIcon: Glide $id")
                    Glide.with(context).load(ContentUris.withAppendedId(imageUri, id))
                        .placeholder(R.drawable.ic_images)
                        .into(fileIcon)
                }

                FileTypes.WORDX -> {
                    Glide.with(context).load(R.drawable.ic_extension_doc)
                        .into(fileIcon)
                }

                FileTypes.PPTX -> {
                    Glide.with(context).load(R.drawable.ic_extension_ppt)
                        .into(fileIcon)
                }

                FileTypes.EXCELX -> {
                    Glide.with(context).load(R.drawable.ic_extension_excel)
                        .into(fileIcon)
                }
                FileTypes.ZIP ->{
                    Glide.with(context).load(R.drawable.ic_zip).into(fileIcon)
                }
                else -> {
                    Glide.with(context).load(R.drawable.ic_files)
                        .into(fileIcon)
                }
            }
        }


        fun launchDocSupportedIntent(context: Context, filePath: String, fileType: String) {
            val file: File = File(filePath)
            Log.e("TAG", "launchDocSupportedIntent: ${file.exists()}")
            val uriPdfPath = FileProvider.getUriForFile(
                context,
                context.packageName + ".provider",
                file
            )
            val pdfOpenIntent = Intent(Intent.ACTION_VIEW)
            pdfOpenIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            pdfOpenIntent.clipData = ClipData.newRawUri("", uriPdfPath);
            pdfOpenIntent.setDataAndType(uriPdfPath, fileType)
            pdfOpenIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)

            try {
                context.startActivity(pdfOpenIntent)
            } catch (activityNotFoundException: ActivityNotFoundException) {
                Toast.makeText(
                    context,
                    "There is no app to load corresponding File",
                    Toast.LENGTH_LONG
                ).show()
            }
        }


        fun File.copyTo(filePath:String){
            val file = File(filePath)
            inputStream().use { input ->
                file.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
        }
        fun launchImageIntent(context: Context, filePath: String) {
            val imageFile: File = File(filePath)
            if (imageFile.exists()) {
                val imageUri = Uri.fromFile(imageFile)

                val intent = Intent(Intent.ACTION_VIEW)
                intent.setDataAndType(imageUri, "image/*")
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

                try {
                    context.startActivity(intent)
                } catch (e: java.lang.Exception) {
                    Log.e("TAG", "launchImageIntent: $e", )
                    Toast.makeText(
                        context,
                        "No suitable app found to open the image",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } else {
                Toast.makeText(context, "Image file not found", Toast.LENGTH_SHORT).show()
            }
        }

        fun launchApkIntent(context: Context, filePath: String) {
            val uri = FileProvider.getUriForFile(
                context,
                context.applicationContext.packageName + ".provider",
                File(filePath)
            )
            val intent = Intent(Intent.ACTION_VIEW)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent.setDataAndType(uri, "application/vnd.android.package-archive")
            context.startActivity(intent)
        }

        fun deleteFiles(value: MutableList<QuickFileModel>, deleteDone: MutableStateFlow<Boolean>) {
            Log.e("TAG", "deleteFiles: ${value.size}")
            CoroutineScope(Dispatchers.IO).launch {
                repeat(value.size) {
                    val file = File(value[it].filePath)
                    Log.e("TAG", "deleteFiles: ${value[it].filePath}")
                    if (file.exists()) {
//                        val delete = file.delete()
                        Log.e("TAG", "deleteFiles: Deleted")
                    }
                }
                deleteDone.update {
                    true
                }

            }
        }
    }

}