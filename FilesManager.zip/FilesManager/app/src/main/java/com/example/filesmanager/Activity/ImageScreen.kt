package com.example.filesmanager.Activity

import android.app.Dialog
import android.content.ContentUris
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.Window
import android.view.WindowManager
import android.widget.CheckBox
import android.widget.LinearLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.net.toFile
import androidx.viewpager2.widget.ViewPager2
import com.example.filesmanager.Adapter.ImageAdapter
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.Utils.Helper.Companion.copyTo
import com.example.filesmanager.Utils.StringConstant
import com.example.filesmanager.databinding.ActivityImageScreenBinding
import com.yalantis.ucrop.UCrop
import java.io.File


class ImageScreen : AppCompatActivity() {
    private lateinit var binding: ActivityImageScreenBinding

    private final val TAG = "SingleImage"
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        val rotateList = List(Helper.imageFolder.size) { 0f }.toMutableList()
        var imageIndex = 0
        binding = ActivityImageScreenBinding.inflate(layoutInflater)

        setContentView(binding.root)
        binding.appbar.backBtn.setOnClickListener {
            finish()
        }

        binding.appbar.appTitle.text = Helper.imageFolder[Helper.imagePosition].fileName


        val imageSlider = ImageAdapter(Helper.imageFolder, rotateList)
        binding.vpImageSlider.adapter = imageSlider
        binding.vpImageSlider.setCurrentItem(Helper.imagePosition, false)
        binding.vpImageSlider.registerOnPageChangeCallback(object :
            ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                binding.appbar.appTitle.text = Helper.imageFolder[position].fileName
                Helper.imagePosition = position
                super.onPageSelected(position)
            }
        })


        binding.llRotate.setOnClickListener {
            rotateList[imageIndex] += 90f
            imageSlider.rotateImage(rotateList[imageIndex], Helper.imagePosition)
            if (rotateList[imageIndex] == 360f) {
                rotateList[imageIndex] = 0f
            }
        }

        binding.llDelete.setOnClickListener {
            val dialog = Dialog(this, R.style.FullWidthDialog)
            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

            val layoutParams = WindowManager.LayoutParams()
            layoutParams.copyFrom(dialog.window!!.attributes)
            layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT
            layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT

            dialog.window!!.attributes = layoutParams
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(true)

            val view = layoutInflater.inflate(R.layout.confirm_delete_dialog, null)


            val cancelBtn = view.findViewById<AppCompatButton>(R.id.btn_cancel)
            val deleteBtn = view.findViewById<AppCompatButton>(R.id.btn_delete)

            cancelBtn.setOnClickListener {
                dialog.dismiss()
            }

            deleteBtn.setOnClickListener {
                val file = File(Helper.imageFolder[Helper.imagePosition].filePath)
                if(file.exists()){
                    file.delete()
                }
                dialog.dismiss()
                val newFolder = Helper.imageFolder.toMutableList()
                newFolder.remove(Helper.imageFolder[Helper.imagePosition])
                Helper.imageFolder = newFolder
                val imageSlider = ImageAdapter(Helper.imageFolder, rotateList)
                binding.vpImageSlider.adapter = imageSlider
                binding.vpImageSlider.setCurrentItem(Helper.imagePosition, false)

            }
            dialog.setContentView(view)

            dialog.show()
        }

        binding.llShare.setOnClickListener {
            val shareIntent = Intent(Intent.ACTION_SEND)
            shareIntent.type = "image/jpeg"
            shareIntent.putExtra(
                Intent.EXTRA_STREAM,
                ContentUris.withAppendedId(
                    Helper.imageUri,
                    Helper.imageFolder[Helper.imagePosition].id
                )
            )
            startActivity(shareIntent)
        }

        binding.llCrop.setOnClickListener {
            val file = File(cacheDir.absolutePath + "/temp.jpg")
            if (!file.exists())
                file.createNewFile()
            val crop = UCrop.of(
                ContentUris.withAppendedId(
                    Helper.imageUri,
                    Helper.imageFolder[Helper.imagePosition].id
                ), Uri.fromFile(file)
            )
                .withMaxResultSize(120, 120)

            val cropIntent = crop.getIntent(this)
            cropIntent.data = Uri.fromFile(file)
            cropIntentResult.launch(cropIntent)
        }

    }

    val cropIntentResult =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val resultUri: Uri = UCrop.getOutput(result.data!!)!!

                val download =
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val folder = File(download!!.absolutePath + "/FileManager")
                if (!folder.exists()) {
                    folder.mkdir()
                }

                val lastIndex = Helper.imageFolder[Helper.imagePosition].fileName.lastIndexOf(".")
                val fileName =
                    Helper.imageFolder[Helper.imagePosition].fileName.substring(0, lastIndex)
                val file =
                    File(folder.absolutePath + "/${fileName}" + "_crop.jpg")

                if (!file.exists()) {
                    file.createNewFile()
                }

                val imageFile = resultUri.toFile()

                imageFile.copyTo(file.absolutePath)

                imageFile.delete()

            } else {
                Log.e(TAG, "Failed: ")
            }
        }
}