package com.example.filesmanager.Activity

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.filesmanager.R
import com.example.filesmanager.Utils.StringConstant
import com.example.filesmanager.databinding.ActivitySettingScreenBinding

class SettingScreen : AppCompatActivity() {
    private lateinit var binding: ActivitySettingScreenBinding
    private lateinit var sharePref: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySettingScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharePref = applicationContext.getSharedPreferences(StringConstant.packageName, MODE_PRIVATE)

        val inAppImage = sharePref.getBoolean(StringConstant.inAppImage,true)
        val inAppMusic = sharePref.getBoolean(StringConstant.inAppMusic,true)
        val inAppVideo = sharePref.getBoolean(StringConstant.inAppVideo,true)

        binding.cbImageViewer.isChecked = inAppImage
        binding.cbMusicViewer.isChecked = inAppMusic
        binding.cbVideoViewer.isChecked = inAppVideo
        binding.cbImageViewer.setOnCheckedChangeListener { buttonView, isChecked ->
            sharePref.edit {
                putBoolean(StringConstant.inAppImage,isChecked)
                apply()
            }
        }


        binding.tvFaq.setOnClickListener {
            val newIntent = Intent(this,FaqScreen::class.java)
            startActivity(newIntent)
        }
        binding.cbMusicViewer.setOnCheckedChangeListener { buttonView, isChecked ->
            sharePref.edit {
                putBoolean(StringConstant.inAppMusic,isChecked)
                apply()
            }
        }

        binding.cbVideoViewer.setOnCheckedChangeListener { buttonView, isChecked ->
            sharePref.edit {
                putBoolean(StringConstant.inAppVideo,isChecked)
                apply()
            }
        }

        binding.appbar.appTitle.text = "Setting Screen"
        binding.appbar.backBtn.setOnClickListener {
            finish()
        }
        binding.btnProScreen.setOnClickListener {
            val newIntent = Intent(this,ProScreen::class.java)
            newIntent.putExtra("fromPro",true)
            startActivity(newIntent)
        }

    }
}