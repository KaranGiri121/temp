package com.example.filesmanager.Activity

import android.content.ComponentName
import android.content.ContentUris
import android.content.Intent
import android.content.ServiceConnection
import android.net.Uri
import android.os.Bundle
import android.os.IBinder
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.example.filesmanager.Model.MusicModel
import com.example.filesmanager.R
import com.example.filesmanager.Service.MusicService
import com.example.filesmanager.Utils.AppConstant
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.databinding.ActivityMusicPlayerScreenBinding
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MusicPlayerScreen : AppCompatActivity() {


    private lateinit var binding: ActivityMusicPlayerScreenBinding

    private lateinit var mService: MusicService
    private var mBound: Boolean = false


    private lateinit var currentMusic: MutableStateFlow<MusicModel>
    private lateinit var isPlaying: MutableStateFlow<Boolean>
    private lateinit var durationValue: MutableStateFlow<Int>
    private lateinit var seekHandler: MutableStateFlow<Int>


    private val connection = object : ServiceConnection {

        override fun onServiceConnected(className: ComponentName, service: IBinder) {

            val binder = service as MusicService.MusicServiceBinder
            mService = binder.getService()
            binder.setMusicList(AppConstant.musicPlayList)
            binder.setMusicIndex(AppConstant.musicIndex)
            currentMusic = binder.currentMusic()
            isPlaying = binder.isPlayer()
            durationValue = binder.getTotalDuration()
            seekHandler = binder.getSeekHandler()
            lifecycleScope.launch {
                mService.loopState.collectLatest {
                    Log.e("TAG", "onServiceConnected: $it")
                    when (it) {
                        AppConstant.LoopState.DISABLE -> {
                            binding.ivMusicRepeat.alpha = 0.5f
                            binding.ivMusicRepeat.setImageDrawable(
                                AppCompatResources.getDrawable(
                                    this@MusicPlayerScreen,
                                    R.drawable.ic_repeat
                                )
                            )
                        }

                        AppConstant.LoopState.SELF -> {
                            binding.ivMusicRepeat.alpha = 1f
                            binding.ivMusicRepeat.setImageDrawable(
                                AppCompatResources.getDrawable(
                                    this@MusicPlayerScreen,
                                    R.drawable.ic_repeat_self
                                )
                            )

                        }

                        AppConstant.LoopState.TRACK -> {
                            binding.ivMusicRepeat.alpha = 1f
                            binding.ivMusicRepeat.setImageDrawable(
                                AppCompatResources.getDrawable(
                                    this@MusicPlayerScreen,
                                    R.drawable.ic_repeat
                                )
                            )
                        }
                    }
                }
            }
            lifecycleScope.launch {
                currentMusic.collectLatest {
                    binding.appbar.appTitle.text = it.fileName
                    Glide.with(this@MusicPlayerScreen)
                        .load(
                            Uri.parse("content://media/external/audio/albumart/${it.posterUri}")
                        ).placeholder(R.drawable.ic_music_disc)
                        .into(binding.ivMusicCover)
                    binding.tvMusicName.text = it.fileName
                    binding.tvArtistName.text = it.artistName
                    binding.sbVideoProgress.max = it.duration.toInt()
                    binding.sbVideoProgress.progress = 0
                }
            }

            lifecycleScope.launch {
                isPlaying.collectLatest {
                    binding.ivMusicPlay.setImageDrawable(
                        AppCompatResources.getDrawable(
                            this@MusicPlayerScreen,
                            if (it) R.drawable.ic_pause_btn else R.drawable.ic_play_btn_drawable
                        )
                    )
                }
            }

            lifecycleScope.launch {
                durationValue.collectLatest {
                    binding.tvMusicTotalDuration.text = Helper.getDuration(it.toLong())
                }
            }
            lifecycleScope.launch {
                seekHandler.collectLatest {
                    binding.sbVideoProgress.progress = it
                }
            }
            if (intent.data != null) {
                mService.singleOne(intent.data!!)
            } else
                mService.initializeMediaPlayer()

            mBound = true
        }

        override fun onServiceDisconnected(arg0: ComponentName) {
            mBound = false
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMusicPlayerScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.appbar.backBtn.setOnClickListener {
            finish()
        }

        Intent(this, MusicService::class.java).also { intent ->
            startService(intent)
            bindService(intent, connection, BIND_AUTO_CREATE)
        }

        binding.ivMusicNext.setOnClickListener {
            mService.nextSong()
        }

        binding.ivMusicPrevious.setOnClickListener {
            mService.previousSong()
        }

        binding.ivMusicPlay.setOnClickListener {
            mService.playAndPause()
        }

        binding.ivMusicShuffle.setOnClickListener {
            mService.shuffleTrack()
        }

        binding.ivMusicRepeat.setOnClickListener {
            mService.changeLoopStatus()
        }

        binding.tvUpNext.setOnClickListener {
            val modalBottomSheet = MusicUpNextSheet(mService.getMusicList())
            modalBottomSheet.show(supportFragmentManager, MusicUpNextSheet.TAG)
        }

        binding.sbVideoProgress.setOnSeekBarChangeListener(object :
            SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.tvMusicProgressDuration.text = Helper.getDuration(progress.toLong())
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {

            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                mService.seekTo(seekBar?.progress ?: 0)
            }

        })
    }

    override fun onDestroy() {
        super.onDestroy()
    }
}

class MusicUpNextSheet(val arr: List<MusicModel>) : BottomSheetDialogFragment() {

    private var behavior: BottomSheetBehavior<View>? = null
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.music_up_next_bottom_sheet, container, false)
        val list = view.findViewById<ListView>(R.id.up_next_list)
        val dragHandle = view.findViewById<View>(R.id.handle)
        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_list_item_1,
            arr.map { it.fileName })
        list.adapter = adapter
        dialog?.setCanceledOnTouchOutside(true) // Allow clicking outside to dismiss

        list.setOnTouchListener { _, _ ->
            behavior?.isDraggable = false
            false
        }

        dragHandle.setOnTouchListener { _, _ ->
            behavior?.isDraggable = true
            false
        }
        return view
    }

    override fun onStart() {
        super.onStart()
        val dialog = dialog as? BottomSheetDialog
        val bottomSheet =
            dialog?.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)

        bottomSheet?.let {
            behavior = BottomSheetBehavior.from(it)
            behavior?.state = BottomSheetBehavior.STATE_EXPANDED // Keep open initially

            behavior?.addBottomSheetCallback(object : BottomSheetBehavior.BottomSheetCallback() {
                override fun onStateChanged(bottomSheet: View, newState: Int) {
                    if (newState == BottomSheetBehavior.STATE_DRAGGING) {
                        behavior?.isDraggable =
                            true // Allow dragging only when the handle is touched
                    }
                }

                override fun onSlide(bottomSheet: View, slideOffset: Float) {
                    // No action needed
                }
            })
        }
    }

    companion object {
        const val TAG = "ModalBottomSheet"
    }
}