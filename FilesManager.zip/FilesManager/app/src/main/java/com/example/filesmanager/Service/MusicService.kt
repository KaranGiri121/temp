package com.example.filesmanager.Service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.ContentUris
import android.content.Intent
import android.media.MediaMetadata
import android.media.MediaPlayer
import android.net.Uri
import android.os.Binder
import android.os.IBinder
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.filesmanager.Model.MusicModel
import com.example.filesmanager.R
import com.example.filesmanager.Utils.AppConstant
import com.example.filesmanager.Utils.Helper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class MusicService : Service() {


    private var binder = MusicServiceBinder()
    private var musicList: MutableList<MusicModel> = mutableListOf()
    private var musicPiece: MutableStateFlow<MusicModel> = MutableStateFlow(MusicModel())
    private var isPlaying: MutableStateFlow<Boolean> = MutableStateFlow(false)
    private var seekHandler: MutableStateFlow<Int> = MutableStateFlow(0)
    var loopState: MutableStateFlow<AppConstant.LoopState> =
        MutableStateFlow(AppConstant.LoopState.DISABLE)

    private var durationHandler: MutableStateFlow<Int> = MutableStateFlow(0)
    private var durationJob: Job? = null

    private var musicIndex: Int = 0
    private var mediaPlayer: MediaPlayer? = null
    override fun onBind(intent: Intent): IBinder {
        return binder
    }

    inner class MusicServiceBinder : Binder() {
        fun getService(): MusicService = this@MusicService
        fun setMusicList(newMusic: List<MusicModel>) {
            musicList = newMusic.toMutableList()
        }

        fun setMusicIndex(newIndex: Int) {
            musicIndex = newIndex
        }

        fun isPlayer(): MutableStateFlow<Boolean> = isPlaying

        fun currentMusic(): MutableStateFlow<MusicModel> = musicPiece

        fun getTotalDuration(): MutableStateFlow<Int> = durationHandler

        fun getSeekHandler(): MutableStateFlow<Int> = seekHandler


    }

    fun getMusicList(): List<MusicModel> = musicList
    fun getCurrentDuration(): Int = mediaPlayer?.currentPosition ?: 0


    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action

        action?.let {

            val state = AppConstant.MediaState.fromState(action)
            when (state) {
                AppConstant.MediaState.START_NEW -> {
                    singleOne(intent.data!!)
                }

                AppConstant.MediaState.NEXT -> {
                    nextSong()
                }

                AppConstant.MediaState.PREV -> {
                    previousSong()
                }

                AppConstant.MediaState.PLAY -> {
                    playAndPause()
                }

                AppConstant.MediaState.PAUSE -> {
                    playAndPause()
                }

                null -> {
                }

            }
        }
        return START_STICKY
    }

    fun singleOne(path: Uri) {
        Log.e("TAG", "initializeMediaPlayer: Start")
        mediaPlayer?.stop()
        mediaPlayer?.release()

        mediaPlayer = MediaPlayer.create(
            this, path
        )
        mediaPlayer?.prepare()
        mediaPlayer?.setOnPreparedListener {
            mediaPlayer?.start()
            isPlaying.update {
                true
            }

            durationHandler.update {
                mediaPlayer?.duration ?: 0
            }

            sendNotification(musicPiece.value)
        }
    }

    fun initializeMediaPlayer() {
        durationJob?.cancel()
        val newMusicPiece = musicList[musicIndex]
        musicPiece.update {
            newMusicPiece
        }
        mediaPlayer?.stop()
        mediaPlayer?.release()

        mediaPlayer = MediaPlayer.create(
            this, ContentUris.withAppendedId(Helper.musicUri, musicPiece.value.id)
        )

        mediaPlayer?.setOnPreparedListener {
            mediaPlayer?.start()
            isPlaying.update {
                true
            }
            mediaPlayer?.setOnCompletionListener {
                Log.e("TAG", "initializeMediaPlayer: Complete")
                nextSong()
            }
            durationHandler.update {
                mediaPlayer?.duration ?: 0
            }

            durationJob = CoroutineScope(Dispatchers.IO).launch {
                var duration = 0
                do {
                    duration = getCurrentDuration()
                    seekHandler.update {
                        duration
                    }
                    delay(1000)
                } while (duration < mediaPlayer?.duration!!)
            }


            sendNotification(musicPiece.value)
        }
    }

    fun playAndPause() {
        if (mediaPlayer?.isPlaying == true) {
            mediaPlayer?.pause()
        } else {
            mediaPlayer?.start()
        }

        isPlaying.update {
            mediaPlayer?.isPlaying ?: false
        }
        sendNotification(musicPiece.value)
    }

    fun seekTo(pos: Int) {
        mediaPlayer?.seekTo(pos)
    }

    fun nextSong() {
        Log.e("TAG", "nextSong: ")
        if (loopState.value != AppConstant.LoopState.SELF) {
            if (musicIndex == musicList.size - 1) {
                if (loopState.value == AppConstant.LoopState.TRACK) {
                    musicIndex = 0
                } else if (loopState.value == AppConstant.LoopState.DISABLE) {
                    return
                }
            } else {
                musicIndex = musicIndex.plus(1)
            }
        }
        initializeMediaPlayer()
    }

    fun previousSong() {
        if (musicIndex != 0) {
            musicIndex = musicIndex.minus(1)
        }
        initializeMediaPlayer()
    }

    fun shuffleTrack() {
        val newTrack = musicList
        val musicPiece = musicList[musicIndex]
        newTrack.remove(musicPiece)
        newTrack.shuffle()
        musicList = newTrack
    }

    fun changeLoopStatus() {
        Log.e("TAG", "changeLoopStatus: Hit")
        if (loopState.value == AppConstant.LoopState.DISABLE) {
            loopState.update {
                AppConstant.LoopState.TRACK
            }
        } else if (loopState.value == AppConstant.LoopState.TRACK) {
            loopState.update {
                AppConstant.LoopState.SELF
            }
        } else {
            loopState.update {
                AppConstant.LoopState.DISABLE
            }
        }

    }

    fun sendNotification(musicPiece: MusicModel) {

        val mediaSession = MediaSessionCompat(this, "MusicPlayer")
        val mediaStyle = androidx.media.app.NotificationCompat.MediaStyle()
            .setMediaSession(mediaSession.sessionToken)
            .setShowActionsInCompactView(0, 1, 2, 3, 4)


        val pauseAction = NotificationCompat.Action.Builder(
            R.drawable.ic_pause_btn_drawable, "Pause",
            PendingIntent.getService(this, 121, Intent(this, MusicService::class.java).apply {
                action = "Pause"
            }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
        ).build()


        val playAction = NotificationCompat.Action.Builder(
            R.drawable.ic_play_btn_drawable, "Play",
            PendingIntent.getService(this, 121, Intent(this, MusicService::class.java).apply {
                action = "Play"
            }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
        ).build()

        val nextAction = NotificationCompat.Action.Builder(
            R.drawable.ic_next_btn_drawable, "Next",
            PendingIntent.getService(this, 121, Intent(this, MusicService::class.java).apply {
                action = "Next"
            }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
        ).build()

        val previous = NotificationCompat.Action.Builder(
            R.drawable.ic_previous_btn_drawable, "Previous",
            PendingIntent.getService(this, 121, Intent(this, MusicService::class.java).apply {
                action = "Previous"
            }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
        ).build()

        val notification = NotificationCompat.Builder(this, "12").setStyle(mediaStyle)
            .setContentTitle("Music Player")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setPriority(Notification.PRIORITY_MAX).setWhen(0)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)


        notification.addAction(previous)
        Log.e("TAG", "sendNotification: ${isPlaying.value}  ${musicPiece.fileName}")
        if (isPlaying.value)
            notification.addAction(pauseAction)
        else
            notification.addAction(playAction)

        notification.addAction(nextAction)


        if (isPlaying.value) {
            mediaSession.setMetadata(
                MediaMetadataCompat.Builder()
                    .putString(MediaMetadata.METADATA_KEY_TITLE, musicPiece.fileName)
                    .putString(MediaMetadata.METADATA_KEY_ARTIST, musicPiece.artistName).putString(
                        MediaMetadata.METADATA_KEY_ALBUM_ART_URI,
                        ContentUris.withAppendedId(Helper.musicUri, 1000000055).toString()
                    ).putLong(
                        MediaMetadata.METADATA_KEY_DURATION, musicPiece.duration
                    ).build()
            )
        }
        val state =
            if (isPlaying.value) PlaybackStateCompat.STATE_PLAYING else PlaybackStateCompat.STATE_STOPPED

        mediaSession.setPlaybackState(
            PlaybackStateCompat.Builder().setState(
                state,
                mediaPlayer?.currentPosition!!.toLong(),
                1F
            ).setActions(
                PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE or PlaybackStateCompat.ACTION_SEEK_TO or PlaybackStateCompat.ACTION_SKIP_TO_NEXT or PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS
            ).build()
        )

        mediaSession.setCallback(object : MediaSessionCompat.Callback() {
            override fun onSeekTo(pos: Long) {
                mediaPlayer?.seekTo(pos.toInt())
            }
        })
        startForeground(121, notification.build())
    }

//    private var mediaPlayer: MediaPlayer? = null
//    private var binder = MusicBinder()
//    val isPlaying: MutableLiveData<Boolean> = MutableLiveData(true)
//
//    override fun onBind(intent: Intent): IBinder {
//        return binder
//    }
//
//    fun getDuration(): Int {
//        return mediaPlayer?.currentPosition ?: 0
//    }
//
//    fun setDuration(position: Int) {
//        mediaPlayer?.seekTo(position)
//    }
//
//    fun pauseAndPlay() {
//        if (mediaPlayer?.isPlaying!!) {
//            mediaPlayer?.pause()
//            isPlaying.postValue(false)
//            notificationHandler(false, null)
//        } else {
//            mediaPlayer?.start()
//            isPlaying.postValue(true)
//            notificationHandler(true, null)
//        }
//    }
//
//    override fun onCreate() {
//        initializedMediaPlayer()
//        super.onCreate()
//    }
//
//    fun initializedMediaPlayer() {
//        val musicPiece = AppConstant.musicPlayList[AppConstant.musicIndex]
//        mediaPlayer = MediaPlayer.create(this, ContentUris.withAppendedId(Helper.musicUri, musicPiece.id))
//        mediaPlayer?.start()
//        notificationHandler(true, musicPiece)
//    }
//
//    fun cleanAndRelease(){
//        mediaPlayer?.stop()
//        mediaPlayer?.release()
//    }
//
//    fun notificationHandler(isPlayer: Boolean, musicPiece: MusicModel?) {
//        val mediaSession = MediaSession(this, "PlayerService")
//        val mediaStyle =
//            Notification.MediaStyle().setMediaSession(mediaSession.sessionToken)
//                .setShowActionsInCompactView(0, 1, 2)
//
//        val pauseAction: Notification.Action = Notification.Action.Builder(
//            R.drawable.ic_pause_btn, "Pause", PendingIntent.getService(
//                this,
//                121,
//                Intent(this, MusicService::class.java).apply {
//                    action = "stop"
//                },
//                PendingIntent.FLAG_UPDATE_CURRENT or FLAG_MUTABLE
//            )
//        ).build()
//
//        val playAction: Notification.Action = Notification.Action.Builder(
//            R.drawable.ic_play_btn, "Play", PendingIntent.getService(
//                this,
//                121,
//                Intent(this, MusicService::class.java).apply {
//                    action = "play"
//                },
//                PendingIntent.FLAG_UPDATE_CURRENT or FLAG_MUTABLE
//            )
//        ).build()
//
//        val nextAction = Notification.Action.Builder(
//            R.drawable.ic_next_btn, "Next", PendingIntent.getService(
//                this,
//                121,
//                Intent(this, MusicService::class.java).apply {
//                    action = "next"
//                },
//                PendingIntent.FLAG_UPDATE_CURRENT or FLAG_MUTABLE
//            )
//        ).build()
////
//        val previousAction = Notification.Action.Builder(
//            R.drawable.ic_previous_btn, "Previous", PendingIntent.getService(
//                this,
//                121,
//                Intent(this, MusicService::class.java).apply {
//                    action = "previous"
//                },
//                PendingIntent.FLAG_UPDATE_CURRENT or FLAG_MUTABLE
//            )
//        ).build()
//        val notification = Notification.Builder(this, "12")
//            .setStyle(mediaStyle)
//            .setContentTitle("Music Player")
//            .setSmallIcon(R.drawable.ic_apps)
//            .setPriority(Notification.PRIORITY_MAX)
//            .setWhen(0)
//            .setVisibility(Notification.VISIBILITY_PUBLIC)
//
//        notification.addAction(previousAction)
//
//        if (isPlayer)
//            notification.addAction(pauseAction)
//        else
//            notification.addAction(playAction)
//
//        notification.addAction(nextAction)
//
//        if (musicPiece != null) {
//            mediaSession.setMetadata(
//                MediaMetadata.Builder()
//                    .putString(MediaMetadata.METADATA_KEY_TITLE, musicPiece.fileName)
//                    .putString(MediaMetadata.METADATA_KEY_ARTIST, musicPiece.artistName)
//                    .putString(
//                        MediaMetadata.METADATA_KEY_ALBUM_ART_URI,
//                        ContentUris.withAppendedId(Helper.imageUri, 1000000055).toString()
//                    )
//                    .putLong(
//                        MediaMetadata.METADATA_KEY_DURATION,
//                        musicPiece.duration
//                    )
//                    .build()
//            )
//        }
//        mediaSession.setPlaybackState(
//            PlaybackState.Builder()
//                .setState(
//                    if (isPlayer) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
//                    mediaPlayer?.currentPosition!!.toLong(),
//                    1F
//                )
//                .setActions(PlaybackState.ACTION_SEEK_TO)
//                .build()
//        )
//        startForeground(121, notification.build())
//    }
//
//    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
//        val action = intent?.action
//        Log.e("TAG", "onStartCommand: $action")
//        when (action) {
//            "stop" -> pauseAndPlay()
//            "play" -> pauseAndPlay()
//
//        }
//
//        return super.onStartCommand(intent, flags, startId)
//    }
//
//    override fun onDestroy() {
//        Log.e("TAG", "onDestroy: Destroy")
//        mediaPlayer?.stop()
//        mediaPlayer?.release()
//        super.onDestroy()
//    }
//
//    inner class MusicBinder : Binder() {
//        fun getService(): MusicService = this@MusicService
//    }
}