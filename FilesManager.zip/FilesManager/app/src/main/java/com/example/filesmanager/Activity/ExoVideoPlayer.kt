package com.example.filesmanager.Activity

import android.content.ContentUris
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.databinding.ActivityExoVideoPlayerBinding

class ExoVideoPlayer : AppCompatActivity() {
    private lateinit var binding: ActivityExoVideoPlayerBinding

    private var player: ExoPlayer? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityExoVideoPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val player = ExoPlayer.Builder(this).build();
        binding.playerView.setPlayer(player);
        val mediaItems = mutableListOf<MediaItem>()
        for (i in 0 until Helper.videoFolder.size) {
            val mediaItem = MediaItem.fromUri(
                ContentUris.withAppendedId(Helper.videoUri, Helper.videoFolder[i].id)
            )
            mediaItems.add(mediaItem)
        }


        player.setMediaItems(mediaItems)
        player.seekTo(Helper.videoPosition, 0)
        player.prepare()
        player.playWhenReady = true

    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
    }
}