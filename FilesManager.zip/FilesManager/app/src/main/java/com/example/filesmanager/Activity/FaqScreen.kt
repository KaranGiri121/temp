package com.example.filesmanager.Activity

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.filesmanager.Adapter.FaqHeadingAdapter
import com.example.filesmanager.R
import com.example.filesmanager.databinding.ActivityFaqScreenBinding
import com.example.filesmanager.databinding.FaqSectionBinding

class FaqScreen : AppCompatActivity() {
    private lateinit var binding: ActivityFaqScreenBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityFaqScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.appbar.backBtn.setOnClickListener {
            finish()
        }
        binding.appbar.appTitle.text = "FAQ"
        val faq = mapOf(
            "General Questions" to listOf(
                "What is this application used for?" to "This file manager application helps users manage and organize their files in one place. It provides tools for file browsing, storage analysis, media management, system cleaning, and file sharing.",
                "Is the app compatible with all Android devices?" to "Yes, the app is designed to work with most Android devices running Android version X and above."
            ),
            "File Management" to listOf(
                "How can I view my images and videos in the app?" to "Go to the 'Images' or 'Videos' sections on the home screen to view your media files.",
                "Can I search for specific files?" to "Yes, use the search icon on the home screen to quickly find files by name.",
                "How do I delete a file?" to "Long-press the file you want to delete and tap the delete icon. Confirm the action to permanently remove the file."
            ),
            "Storage Analysis" to listOf(
                "How can I analyze my device storage?" to "Navigate to the 'Storage Analysis' section to get a detailed overview of storage usage, including large files and duplicate files.",
                "Can I clean up storage space with this app?" to "Yes, the 'System Cleaner' feature helps you remove large files, duplicate files, installed APKs, and trash files to free up space."
            ),
            "Media and Document Management" to listOf(
                "How can I access my recent files?" to "Go to the 'Recent Files' section to see files you’ve recently opened or used.",
                "Can I play music directly in the app?" to "Yes, the app allows you to browse and play music files seamlessly."
            ),
            "Download and FTP Support" to listOf(
                "How do I download files using the app?" to "Use the 'Downloads' section to access and manage downloaded files. Tap on the 'Download' button to start downloading a file.",
                "Can I set up an FTP server to transfer files?" to "Yes, go to the 'FTP Server' section to configure and enable file transfers between your device and other systems."
            ),
            "Security and Privacy" to listOf(
                "Does the app access my personal data?" to "The app only accesses files and media on your device with your permission. We do not collect or store any personal data.",
                "Can I safely delete trash files?" to "Yes, trash files are safe to delete and will help free up storage space."
            ),
            "Troubleshooting" to listOf(
                "I cannot see all my files in the app. What should I do?" to "Ensure you have granted storage permissions to the app. If the issue persists, try refreshing the file list.",
                "How do I report a bug or issue with the app?" to "Please visit the 'Help & Support' section in the app or contact us at [support@example.com]."
            )
        )
        val sectionAdapter = FaqHeadingAdapter(this, faq)
        binding.rvFaq.adapter = sectionAdapter
        binding.rvFaq.layoutManager = LinearLayoutManager(this)
    }
}