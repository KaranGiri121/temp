package com.example.filesmanager.Fragment

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.filesmanager.Activity.QuickScanResult
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.databinding.FragmentCleanScreenBinding


class CleanScreen : Fragment() {


    private lateinit var binding: FragmentCleanScreenBinding
    private final val TAG = "CleanScreen"

    private val STORAGE_PERMISSION_CODE: Int = 23
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = FragmentCleanScreenBinding.inflate(inflater, container, false)

        Log.e(TAG, "onCreateView: ${String.format(" % .3f", (Helper.iAvailableSpace.toDouble() / Helper.iTotalSpace.toDouble())*100)}", )
        binding.tvFreeSpace.text = "${
            String.format(" % .2f", (Helper.iAvailableSpace.toDouble() / Helper.iTotalSpace.toDouble())*100)
        }%"
        binding.tvUsedSpace.text = "${
            String.format("%.2f", (Helper.iUsedSpace.toDouble() / Helper.iTotalSpace.toDouble())* 100)
        }%"

        binding.btnQuickScan.setOnClickListener {
            val permissionStatus = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Environment.isExternalStorageManager()
            } else {
                val write =
                    ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE)
                val read =
                    ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_EXTERNAL_STORAGE)

                read == PackageManager.PERMISSION_GRANTED && write == PackageManager.PERMISSION_GRANTED
            }

            if (!permissionStatus) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    try {
                        val intent = Intent()
                        intent.setAction(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                        val uri = Uri.fromParts("package", requireContext().packageName, null)
                        intent.setData(uri)
                        permissionIntent.launch(intent)
                    } catch (e: Exception) {
                        val intent = Intent()
                        intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                        permissionIntent.launch(intent)
                    }
                } else {
                    below11PermissionIntent.launch(
                        arrayOf(
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                        )
                    )
                }
            } else {
                Log.e(TAG, "onCreateView: WithOut Permission", )
                val newIntent = Intent(requireActivity(),QuickScanResult::class.java)
                requireActivity().startActivity(newIntent)
            }
        }
        return binding.root
    }



    val permissionIntent = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                Log.e(TAG, "onCreateView: With Permission", )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                val newIntent = Intent(requireContext(),QuickScanResult::class.java)
                startActivity(newIntent)
            } else {
                Toast.makeText(
                    requireContext(),
                    "Need Storage Permission For Scanning Duplication Files",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    val below11PermissionIntent =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { it ->
            val keys = it.keys
            val value = it.keys
        }


}