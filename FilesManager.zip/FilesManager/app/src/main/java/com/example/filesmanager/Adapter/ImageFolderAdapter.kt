package com.example.filesmanager.Adapter

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.filesmanager.Activity.ImagesList
import com.example.filesmanager.Model.ImageModel
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper

class ImageFolderAdapter(val context: Context, var arr: Map<String, List<ImageModel>>) :
    RecyclerView.Adapter<ImageFolderAdapter.ImageFolderViewHolder>() {


    var data: List<String> = listOf()

    class ImageFolderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val folderContainer = itemView.findViewById<CardView>(R.id.cv_image_folder)
        val folderThumbnail = itemView.findViewById<ImageView>(R.id.iv_imageFolder_thumbnail)
        val folderName = itemView.findViewById<TextView>(R.id.tv_imageFolder_name)
        val folderNumber = itemView.findViewById<TextView>(R.id.tv_imageFolder_number)
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): ImageFolderViewHolder {
        val view = LayoutInflater.from(p0.context).inflate(R.layout.image_folder_layout, p0, false)

        return ImageFolderViewHolder(view)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: ImageFolderViewHolder, position: Int) {
        holder.folderContainer.setOnClickListener {
            Helper.imageFolder = arr[data[holder.absoluteAdapterPosition]] ?: listOf()
            val newIntent = Intent(context, ImagesList::class.java)
            newIntent.putExtra("FolderName",data[holder.absoluteAdapterPosition])
            context.startActivity(newIntent)
        }

        Glide.with(holder.folderThumbnail.context).load(arr[data[holder.absoluteAdapterPosition]]?.get(0)?.let {
            ContentUris.withAppendedId(
                Helper.imageUri,
                it.id
            )
        }).placeholder(R.mipmap.ic_launcher).into(holder.folderThumbnail)

        holder.folderName.text = data[holder.absoluteAdapterPosition]
        holder.folderNumber.text = arr[data[holder.absoluteAdapterPosition]]?.size.toString()
    }

    fun update(newData: Map<String, List<ImageModel>>) {
        data = newData.keys.toList()
        arr = newData
        notifyDataSetChanged()
    }
}