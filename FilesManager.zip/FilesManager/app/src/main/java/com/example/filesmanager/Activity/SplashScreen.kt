package com.example.filesmanager.Activity

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.filesmanager.R
import com.example.filesmanager.Utils.AppConstant
import com.example.filesmanager.Utils.RemoteValue
import com.example.filesmanager.Utils.StringConstant
import com.example.filesmanager.databinding.ActivitySplashScreenBinding
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.ump.ConsentForm
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.FormError
import com.google.android.ump.UserMessagingPlatform
import com.google.firebase.FirebaseApp
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SplashScreen : AppCompatActivity() {
    private lateinit var binding: ActivitySplashScreenBinding
    lateinit var sharedPreferences: SharedPreferences
    private var consentInformation: ConsentInformation? = null
    var adShowing: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences =
            applicationContext.getSharedPreferences(StringConstant.packageName, MODE_PRIVATE)
//        bp = BillingProcessor(this, AppConstant.GOOGLE_PLAY_LICENSE, this)
//        bp.initialize()
        AppConstant.isProEnable = sharedPreferences.getBoolean(StringConstant.proEnable, false)


        val backgroundScope = CoroutineScope(Dispatchers.IO)
        backgroundScope.launch {
            MobileAds.initialize(this@SplashScreen) {

            }
        }
        val params = ConsentRequestParameters.Builder().setTagForUnderAgeOfConsent(false).build()

        consentInformation = UserMessagingPlatform.getConsentInformation(this)

        consentInformation?.requestConsentInfoUpdate(this, params, {
            if (consentInformation?.isConsentFormAvailable!!) {
                loadForm()
            }
        }, { formError -> })
        fetchFirebaseRemoteConfig()

        Handler(Looper.getMainLooper()).postDelayed(Runnable {
            if (!adShowing) {
                redirectTo()
            }
        }, 13000)

    }

    private fun loadForm() {
        UserMessagingPlatform.loadConsentForm(this, { consentForm: ConsentForm ->
            if (consentInformation?.getConsentStatus() === ConsentInformation.ConsentStatus.REQUIRED) {
                consentForm.show(
                    this
                ) { formError: FormError? ->
                    if (consentInformation?.getConsentStatus() === ConsentInformation.ConsentStatus.OBTAINED) {
                        fetchFirebaseRemoteConfig()
                    }
                    loadForm()
                }
            }
        }, { formError: FormError? -> })
    }


    private fun fetchFirebaseRemoteConfig() {
        FirebaseApp.initializeApp(this@SplashScreen)
        val mFirebaseRemoteConfig: FirebaseRemoteConfig = FirebaseRemoteConfig.getInstance()
        val configSettings: FirebaseRemoteConfigSettings =
            FirebaseRemoteConfigSettings.Builder().setMinimumFetchIntervalInSeconds(10).build()
        mFirebaseRemoteConfig.setConfigSettingsAsync(configSettings)
        mFirebaseRemoteConfig.fetchAndActivate().addOnCompleteListener(
                this@SplashScreen,
        ) { task ->
            if (task.isSuccessful) {

//                RemoteValue.showAd = mFirebaseRemoteConfig.getString("showAd") == "1"
//                RemoteValue.privacyLink = mFirebaseRemoteConfig.getString("privacyPolicy")
//                if (RemoteValue.showAd) {
//                    RemoteValue.showAppOpen =
//                        mFirebaseRemoteConfig.getString("showAppOpen") == "1"
//                    if (RemoteValue.showAppOpen) {
//
//                        RemoteValue.appOpen =
//                            mFirebaseRemoteConfig.getString("initialAppOpen")
//                    }
//
//                    RemoteValue.rewardAdId = mFirebaseRemoteConfig.getString("rewardAd")
//                }

                Log.e("TAG", "fetchFirebaseRemoteConfig: ${RemoteValue.privacyLink}",)



                if (RemoteValue.showAd) {
                    val showOnBoarding = sharedPreferences.getBoolean(
                        StringConstant.onBoarding, true
                    )
                    if (RemoteValue.appOpen.isNotEmpty()) {
                        loadAppOpen(RemoteValue.appOpen)
                    } else {
                        redirectTo()
                    }
                } else {
                    redirectTo()
                }

            } else {
                redirectTo()
            }
        }
    }

    private fun loadAppOpen(id: String) {
        val request = AdRequest.Builder().build()
        AppOpenAd.load(
            this, id, request,
            AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(appOpenAd: AppOpenAd) {
                    appOpenAd.fullScreenContentCallback = object : FullScreenContentCallback() {

                        override fun onAdDismissedFullScreenContent() {
                            redirectTo()
                        }

                        override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                            Log.e("TAG", "onAdFailedToShowFullScreenContent: $adError", )
                            redirectTo()
                        }

                        override fun onAdShowedFullScreenContent() {
                        }
                    }
                    adShowing = true
                    appOpenAd.show(this@SplashScreen)
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    Log.e("TAG", "onAdFailedToLoad: $loadAdError", )
                }
            },
        )
    }

    private fun redirectTo() {
        adShowing = true
        val showOnBoarding = sharedPreferences?.getBoolean(
            StringConstant.onBoarding, true
        ) ?: true
        if (showOnBoarding) {
            val newIntent = Intent(this, OnBoarding::class.java)
            startActivity(newIntent)
            finish()
            return
        }
        val privacyShow = sharedPreferences?.getBoolean(
            StringConstant.privacy, true
        ) ?: true
        if (privacyShow) {
            val newIntent = Intent(this, PrivacyScreen::class.java)
            startActivity(newIntent)
            finish()
            return
        }

        if (!AppConstant.isProEnable) {
            val newIntent = Intent(this, ProScreen::class.java)
            newIntent.putExtra("fromPro", false)
            startActivity(newIntent)
            finish()
            return
        }

        val newIntent = Intent(this, HomeScreen::class.java)
        startActivity(newIntent)
        finish()
    }

}