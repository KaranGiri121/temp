package com.example.filesmanager.Activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.filesmanager.Adapter.VideoListAdapter
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.databinding.ActivityVideoListScreenBinding

class VideoListScreen : AppCompatActivity() {
    private lateinit var binding: ActivityVideoListScreenBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityVideoListScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.appbar.backBtn.setOnClickListener {
            finish()
        }

        binding.appbar.appTitle.text = intent.getStringExtra("FolderName")?: "Folder"

        val videoListAdapter = VideoListAdapter(this, Helper.videoFolder)
        binding.rvVideoList.adapter = videoListAdapter
        binding.rvVideoList.layoutManager = LinearLayoutManager(this)
    }
}