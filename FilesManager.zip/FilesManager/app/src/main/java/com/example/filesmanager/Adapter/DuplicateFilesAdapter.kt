package com.example.filesmanager.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.TextView
import com.example.filesmanager.Model.QuickFileModel
import com.example.filesmanager.R
import kotlinx.coroutines.flow.MutableStateFlow

class DuplicateFilesAdapter(
    context: Context,
    private val arr: List<List<QuickFileModel>>,
    val deleteFile: MutableStateFlow<MutableList<QuickFileModel>>,
    val deleteSize: MutableStateFlow<Long>
) :
    ArrayAdapter<QuickFileModel>(context, 0, arr.size) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view = convertView

        if (view == null) {
            view =
                LayoutInflater.from(context).inflate(R.layout.duplicate_files_layout, parent, false)
        }

        val fileName = view!!.findViewById<TextView>(R.id.tv_fileName)
        val list = view.findViewById<LinearLayout>(R.id.lv_duplicate_file)

        val adapter = DuplicateFileListAdapter(context, arr[position],deleteFile,deleteSize)
        for (i in 0 until arr[position].size) {
            fileName.text = arr[position].first().fileName
            val view = adapter.getView(i, null, list)
            list.addView(view)
        }

        return view
    }
}