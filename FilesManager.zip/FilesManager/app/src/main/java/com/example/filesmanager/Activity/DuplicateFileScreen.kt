package com.example.filesmanager.Activity

import android.os.Bundle
import android.util.Log
import android.view.View.GONE
import android.view.View.VISIBLE
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.filesmanager.Adapter.DuplicateFilesAdapter
import com.example.filesmanager.Model.QuickFileModel
import com.example.filesmanager.Utils.AppConstant
import com.example.filesmanager.Utils.CommonViewModel
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.databinding.ActivityDuplicateFileScreenBinding
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class DuplicateFileScreen : AppCompatActivity() {
    private lateinit var binding: ActivityDuplicateFileScreenBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDuplicateFileScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.appbar.appTitle.text = "Duplicate Files"
        binding.appbar.backBtn.setOnClickListener {
            finish()
        }

        val viewModel = CommonViewModel.cleanViewModel

        val duplicateFile: MutableList<List<QuickFileModel>> = mutableListOf()
        val keys = viewModel.duplicateFile.value?.keys ?: listOf()

        val deleteFile: MutableStateFlow<MutableList<QuickFileModel>> =
            MutableStateFlow(mutableListOf())
        val deleteSize: MutableStateFlow<Long> = MutableStateFlow(0)
        val deleteDone: MutableStateFlow<Boolean> = MutableStateFlow(false)

        lifecycleScope.launch {
            deleteSize.collectLatest {
                deleteDone.update {
                    false
                }
                if (it > 0) {
                    binding.llCleanBottom.visibility = VISIBLE
                    binding.tvFinalTotalClean.text = Helper.formatSize(it)
                } else {
                    binding.llCleanBottom.visibility = GONE
                }
            }
        }

        lifecycleScope.launch {

            deleteDone.collectLatest {
                if(it){
                    val newData = viewModel.duplicateFile.value?: hashMapOf()
                    for(i in newData.entries){
                        i.value.removeAll(deleteFile.value)
                    }
                    viewModel.duplicateFile.postValue(newData)

                    deleteSize.update {
                        0
                    }

                    duplicateFile.clear()
                    for (i in keys.indices) {
                        val values = viewModel.duplicateFile.value!![keys.elementAt(i)]!!
                        duplicateFile.add(values)
                    }
                    binding.rvDuplicateFile.removeAllViews()
                    val adapter = DuplicateFilesAdapter(this@DuplicateFileScreen, duplicateFile, deleteFile, deleteSize)
                    for (i in 0 until duplicateFile.size) {
                        binding.rvDuplicateFile.addView(adapter.getView(i, null, binding.rvDuplicateFile))
                    }
                }
            }
        }

        binding.btnFinalClean.setOnClickListener {
            Helper.deleteFiles(deleteFile.value,deleteDone)
        }
        for (i in keys.indices) {
            val values = viewModel.duplicateFile.value!![keys.elementAt(i)]!!
            duplicateFile.add(values)
        }

        val adapter = DuplicateFilesAdapter(this, duplicateFile, deleteFile, deleteSize)
        for (i in 0 until duplicateFile.size) {
            binding.rvDuplicateFile.addView(adapter.getView(i, null, binding.rvDuplicateFile))
        }
    }
}