package com.example.filesmanager.Activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.filesmanager.Adapter.DuplicateFilesAdapter
import com.example.filesmanager.Model.QuickFileModel
import com.example.filesmanager.Utils.AppConstant
import com.example.filesmanager.databinding.ActivityDuplicateFileScreenBinding

class DuplicateFileScreen : AppCompatActivity() {
    private lateinit var binding: ActivityDuplicateFileScreenBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDuplicateFileScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val duplicateFile :MutableList<List<QuickFileModel>> = mutableListOf()
        val keys = AppConstant.duplicateFileList.keys

        for(i in 0 until keys.size){
            val values = AppConstant.duplicateFileList.get(keys.elementAt(i))!!
            duplicateFile.add(values)
        }

        val adapter = DuplicateFilesAdapter(this,duplicateFile)
        for(i in 0 until duplicateFile.size){
            binding.rvDuplicateFile.addView(adapter.getView(i,null,binding.rvDuplicateFile))
        }
    }
}