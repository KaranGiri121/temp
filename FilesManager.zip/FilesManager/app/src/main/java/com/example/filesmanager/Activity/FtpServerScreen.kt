package com.example.filesmanager.Activity

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.text.Editable
import android.text.format.Formatter
import android.util.Log
import android.view.View.GONE
import android.view.View.VISIBLE
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.content.ContextCompat
import com.example.filesmanager.R
import com.example.filesmanager.Utils.FtpServer
import com.example.filesmanager.databinding.ActivityFtpServerScreenBinding

class FtpServerScreen : AppCompatActivity() {
    private lateinit var binding: ActivityFtpServerScreenBinding

    val ftpServer: FtpServer = FtpServer()
    var isServerOn = false
    private final val TAG = "FtpServerScreen"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFtpServerScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.appbar.appTitle.text = "FTP Server"
        binding.appbar.backBtn.setOnClickListener {
            finish()
        }

        val random6Digit = (100000..999999).random()
        val randomPort = (5000..8999).random()

        binding.edPassword.text =Editable.Factory.getInstance().newEditable(random6Digit.toString())
        binding.edUsername.text = Editable.Factory.getInstance().newEditable("pc")
        binding.cbRandomValue.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                binding.edUsername.text = Editable.Factory.getInstance().newEditable("pc")
                binding.edUsername.isEnabled = false
                binding.edUsername.background =
                    AppCompatResources.getDrawable(this, R.drawable.disable_input_field_outline)

                binding.edPassword.text = Editable.Factory.getInstance().newEditable((5000..8999).random().toString())
                binding.edPassword.isEnabled = false
                binding.edPassword.background =
                    AppCompatResources.getDrawable(this, R.drawable.disable_input_field_outline)
            } else {
                binding.edUsername.isEnabled = true
                binding.edUsername.background =
                    AppCompatResources.getDrawable(this, R.drawable.input_field_outline)

                binding.edPassword.isEnabled = true
                binding.edPassword.background =
                    AppCompatResources.getDrawable(this, R.drawable.input_field_outline)
            }
        }


        binding.btnServer.setOnClickListener {
            val permissionStatus = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Environment.isExternalStorageManager()
            } else {
                val write =
                    ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    )
                val read =
                    ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.READ_EXTERNAL_STORAGE
                    )

                read == PackageManager.PERMISSION_GRANTED && write == PackageManager.PERMISSION_GRANTED
            }

            if (!permissionStatus) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    var result = false
                    try {
                        val intent = Intent()
                        intent.setAction(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                        val uri = Uri.fromParts("package", this.packageName, null)

                        intent.setData(uri)
                        permissionIntent.launch(intent)
                    } catch (e: Exception) {
                        val intent = Intent()
                        intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                        permissionIntent.launch(intent)
                    }
                } else {
                    below11PermissionIntent.launch(
                        arrayOf(
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                        )
                    )
                }
            } else {
                if (!isServerOn) {
                    if (binding.cbRandomValue.isChecked) {
                        startServer("pc", random6Digit.toString(), randomPort)
                    } else {
                        if (binding.edUsername.text.toString().isEmpty()) {
                            Toast.makeText(this, "Username Cannot Be Empty", Toast.LENGTH_SHORT)
                                .show()
                            return@setOnClickListener
                        }
                        if (binding.edPassword.text.toString().isEmpty()) {
                            Toast.makeText(this, "Password Cannot Be Empty", Toast.LENGTH_SHORT)
                                .show()
                            return@setOnClickListener
                        }
                        startServer(
                            binding.edUsername.text.toString(),
                            binding.edPassword.text.toString(),
                            randomPort
                        )
                    }
                } else {
                    stopServer()
                }
            }
        }

    }


    fun startServer(username: String, password: String, port: Int) {
        val wm: WifiManager = getSystemService(Context.WIFI_SERVICE) as WifiManager
        val ipAddress = Formatter.formatIpAddress(wm.connectionInfo.ipAddress)

        Log.e(TAG, "startServer: $ipAddress")
        try {
            ftpServer.startServer(username, password, port, applicationContext)
            flipServerStatus()
            putConfigDetails(username, password)
            flipButtonText(true)
            binding.tvServerIp.text = "ftp://$ipAddress:$port"
            isServerOn = true
        } catch (e: Exception) {
            stopServer()
            Toast.makeText(this, "Not Able To Start Server Try After Sometime", Toast.LENGTH_SHORT)
                .show()
        }

    }

    private fun stopServer() {
        ftpServer.stopServer()
        flipServerStatus()
        flipButtonText(false)
        isServerOn = false

    }

    fun flipButtonText(start: Boolean) {
        if (start) {
            binding.btnServer.text = "Stop Server"
            binding.tvBtnStatus.text =
                "The FTP server is now running on the local network. Press Button To Stop Server."
        } else {
            binding.btnServer.text = "Start Server"
            binding.tvBtnStatus.text =
                "Click to start the FTP server, which will allow access to files on the local network."
        }
    }

    fun flipServerStatus() {
        binding.llServerConfig.visibility =
            if (binding.llServerConfig.visibility == GONE) VISIBLE else GONE
        binding.llServerValue.visibility =
            if (binding.llServerValue.visibility == GONE) VISIBLE else GONE
    }

    fun putConfigDetails(username: String, password: String) {
        binding.tvServerUsername.text = username
        binding.tvServerPassword.text = password
    }

    override fun onDestroy() {
        if (isServerOn) {
            ftpServer.stopServer()
        }
        super.onDestroy()
    }

    val permissionIntent =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            Log.e(TAG, "onCreateView: With Permission")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {

                } else {
                    Toast.makeText(
                        this,
                        "Need Storage Permission For Scanning Duplication Files",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

    val below11PermissionIntent =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { it ->
            val keys = it.keys
            val value = it.keys
        }
}