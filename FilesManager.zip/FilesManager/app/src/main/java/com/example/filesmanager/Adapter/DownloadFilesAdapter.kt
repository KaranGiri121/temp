package com.example.filesmanager.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.filesmanager.DB.RecentFileDB
import com.example.filesmanager.DB.RecentFileEntity
import com.example.filesmanager.Model.DownloadModel
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.Utils.Helper.FileTypes
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Date

class DownloadFilesAdapter(val context: Context, var arr: List<DownloadModel>) :
    RecyclerView.Adapter<DownloadFilesAdapter.DownloadFilesViewHolder>() {
    class DownloadFilesViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val downloadFiles = itemView.findViewById<LinearLayout>(R.id.ll_download_file)
        val fileName = itemView.findViewById<TextView>(R.id.tv_downloadFile_name)
        val fileSize = itemView.findViewById<TextView>(R.id.tv_downloadFile_size)
        val fileIcon = itemView.findViewById<ImageView>(R.id.iv_downloadFile_icon)
    }

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): DownloadFilesViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.download_file_layout, parent, false)
        return DownloadFilesViewHolder(view)
    }

    override fun getItemCount(): Int {
        return arr.size
    }

    override fun onBindViewHolder(holder: DownloadFilesViewHolder, position: Int) {
        holder.fileName.text = arr[position].fileName
        holder.fileSize.text = Helper.formatSize(arr[position].fileSize)
        Helper.populateIcon(context,Helper.fromMimeType(arr[position].fileType),arr[position].filePath,arr[position].id,holder.fileIcon)
        val extension: FileTypes? = Helper.fromMimeType(arr[position].fileType)
        holder.downloadFiles.setOnClickListener {
            when (extension) {
                FileTypes.APK -> {
                    Helper.launchApkIntent(context, arr[position].filePath)
                }

                FileTypes.AUDIO -> {
                    //Todo
                }

                FileTypes.VIDEO -> {
                    //Todo
                }

                FileTypes.PDF -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[position].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("pdf").toString()
                    )
                }

                FileTypes.TXT -> {
                    Helper.launchDocSupportedIntent(
                        context,
                        arr[position].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("txt").toString()
                    )
                }

                FileTypes.WORD -> {
                    Helper.launchDocSupportedIntent(
                        context,
                        arr[position].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("doc").toString()
                    )
                }

                FileTypes.PPT -> {
                    Helper.launchDocSupportedIntent(
                        context,
                        arr[position].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("ppt").toString()
                    )
                }

                FileTypes.EXCEL -> {
                    Helper.launchDocSupportedIntent(
                        context,
                        arr[position].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("xls").toString()
                    )
                }

                FileTypes.IMAGE -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[position].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("pdf").toString()
                    )
                }

                FileTypes.WORDX -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[position].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("docx").toString()
                    )
                }

                FileTypes.PPTX -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[position].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("pptx").toString()
                    )
                }

                FileTypes.EXCELX -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[position].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("xlsx").toString()
                    )
                }

                else -> {
                    //Todo
//                    Helper.launchDocSupportedIntent(
//                        context, arr[position].filePath,
//                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("pdf").toString()
//                    )
                }
            }
            CoroutineScope(Dispatchers.IO).launch {
                RecentFileDB.getInstance(context).getRecentDao().insertRecent(
                    RecentFileEntity(
                        fileId = arr[position].id,
                        fileName = arr[position].fileName,
                        filePath = arr[position].filePath,
                        openTime = Date().time,
                        fileType = arr[position].fileType
                    )
                )
            }
        }

    }

    fun update(newData: List<DownloadModel>){
        arr = newData
        notifyDataSetChanged()
    }


}