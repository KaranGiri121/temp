package com.example.filesmanager.Activity

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.viewpager2.widget.ViewPager2
import com.example.filesmanager.Adapter.OnBoardingAdapter
import com.example.filesmanager.R
import com.example.filesmanager.Utils.AppConstant
import com.example.filesmanager.Utils.StringConstant
import com.example.filesmanager.databinding.ActivityOnBoardingBinding

class OnBoarding : AppCompatActivity() {
    private lateinit var binding: ActivityOnBoardingBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOnBoardingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val viewPage: ViewPager2 = findViewById(R.id.vp_onBoarding_pager)
        val onBoardingPointer1: CardView = findViewById(R.id.cb_pointer1)
        val onBoardingPointer2: CardView = findViewById(R.id.cb_pointer2)
        val onBoardingPointer3: CardView = findViewById(R.id.cb_pointer3)
//        val templateNative: TemplateView = findViewById(R.id.ktNativeAdStart)

//        if (AdLoad.nativeAd != null) {
//            templateNative.visibility = View.VISIBLE
//            templateNative.setNativeAd(AdLoad.nativeAd)
//        } else {
//            templateNative.visibility = View.GONE
//        }

        val nextBtn: CardView = findViewById(R.id.cv_next_btn)
        val adapter = OnBoardingAdapter(this)
        viewPage.adapter = adapter


        val sharedPreferences: SharedPreferences = applicationContext.getSharedPreferences(
            StringConstant.packageName,
            MODE_PRIVATE
        )

        nextBtn.setOnClickListener {
            val pos = viewPage.currentItem
            if (pos == 2) {
                val newIntent = Intent(this, PrivacyScreen::class.java)
                startActivity(newIntent)
                sharedPreferences.edit().putBoolean(StringConstant.onBoarding, false).apply()
                finish()
            } else {
                viewPage.currentItem += 1
            }
        }

        viewPage.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                if (position == 0) {
                    onBoardingPointer1.setCardBackgroundColor(getColor(R.color.primaryColor))
                    onBoardingPointer2.setCardBackgroundColor(getColor(R.color.grey))
                    onBoardingPointer3.setCardBackgroundColor(getColor(R.color.grey))

                }
                if (position == 1) {
                    onBoardingPointer1.setCardBackgroundColor(getColor(R.color.grey))
                    onBoardingPointer2.setCardBackgroundColor(getColor(R.color.primaryColor))
                    onBoardingPointer3.setCardBackgroundColor(getColor(R.color.grey))
                }
                if (position == 2) {
                    onBoardingPointer1.setCardBackgroundColor(getColor(R.color.grey))
                    onBoardingPointer2.setCardBackgroundColor(getColor(R.color.grey))
                    onBoardingPointer3.setCardBackgroundColor(getColor(R.color.primaryColor))
                }
            }
        })
    }
}