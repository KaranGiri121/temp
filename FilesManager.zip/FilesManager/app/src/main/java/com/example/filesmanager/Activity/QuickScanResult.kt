package com.example.filesmanager.Activity

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.os.Bundle
import android.util.Log
import android.view.View.GONE
import android.view.View.VISIBLE
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.filesmanager.Adapter.QuickFilesAdapter
import com.example.filesmanager.Model.QuickFileModel
import com.example.filesmanager.R
import com.example.filesmanager.Utils.CommonViewModel
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.ViewModel.QuickScanViewModel
import com.example.filesmanager.databinding.ActivityQuickScanResultBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch


class QuickScanResult : AppCompatActivity() {
    private lateinit var binding: ActivityQuickScanResultBinding
    private lateinit var viewModel: QuickScanViewModel
    private final val TAG = "QuickScanResult"
    var shortAnimationDuration: Int = 0
    val deleteDone: MutableStateFlow<Boolean> = MutableStateFlow(false)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQuickScanResultBinding.inflate(layoutInflater)
        shortAnimationDuration = 200
        setContentView(binding.root)


        viewModel = CommonViewModel.cleanViewModel
        if (!viewModel.quickScanDone) {
            CoroutineScope(Dispatchers.IO).launch {
                viewModel.quickScan(contentResolver)
            }
        }


        binding.backBtn.setOnClickListener {
            finish()
        }



        initializeLiveData()
        initializeClickListener()
        lifecycleScope.launch {
            deleteDone.collectLatest {
                if (it) {
                    binding.btnRoundClean.visibility = GONE
                    binding.animationView.setAnimation(R.raw.done_animation)
                    binding.animationView.playAnimation()
                    binding.animationView.repeatCount = ValueAnimator.INFINITE

                    delay(5000)

                    val newLargeFile = viewModel.largeFile.value?.toMutableList() ?: mutableListOf()
                    viewModel.largeFileDelete.value?.let { largeFile ->
                        newLargeFile.removeAll(largeFile)
                    }
                    viewModel.largeFile.postValue(newLargeFile)

                    viewModel.duplicateFile.value?.let { duplicateFile ->

                        for (i in duplicateFile.entries) {
                            viewModel.duplicateFileDelete.value?.let { files ->
                                i.value.removeAll(files)
                            }
                        }
                        viewModel.duplicateFile.postValue(duplicateFile)
                    }

                    viewModel.installedApk.value?.let { installedApk ->
                        var newApk = mutableListOf<QuickFileModel>()
                        newApk.addAll(installedApk)
                        viewModel.installedApkDelete.value?.let { deleteApk ->
                            newApk.removeAll(deleteApk)
                        }

                        viewModel.installedApk.postValue(newApk)
                    }


                    viewModel.trashFile.value?.let { trashFile ->
                        var newTrash = mutableListOf<QuickFileModel>()
                        newTrash.addAll(trashFile)
                        viewModel.trashDelete.value?.let { trashDelete ->
                            newTrash.removeAll(trashDelete)
                        }

                        viewModel.trashFile.postValue(newTrash)
                    }

                    viewModel.installedApkDelete.postValue(mutableListOf())
                    viewModel.largeFileDelete.postValue(mutableListOf())
                    viewModel.duplicateFileDelete.postValue(mutableListOf())
                    viewModel.trashDelete.postValue(mutableListOf())
                    
                    binding.animationView.setAnimation(R.raw.ic_background_animation)
                    binding.btnRoundClean.visibility = VISIBLE
                    val value = binding.tvFinalTotalClean.text
                    binding.tvFinalTotalClean.text = "$value"
                    binding.tvFinalTotalText.text = "Free"
                }
            }
        }

    }

    private fun initializeClickListener() {
        binding.ivDuplicateFileDown.setOnClickListener {
            flipVisibility(binding.ivDuplicateFileDown, binding.lvDuplicateFile)
        }

        binding.ivLargeFileDown.setOnClickListener {
            flipVisibility(binding.ivLargeFileDown, binding.lvLargeFile)
        }

        binding.ivInstalledApkDown.setOnClickListener {
            flipVisibility(binding.ivInstalledApkDown, binding.lvInstalledApk)
        }

        binding.ivTrashDown.setOnClickListener {
            flipVisibility(binding.ivTrashDown, binding.lvTrash)
        }

        binding.btnFinalClean.setOnClickListener {
            if (!deleteDone.value) {
                cleanProcess()
            }
        }

        binding.btnRoundClean.setOnClickListener {
            if (!deleteDone.value) {
                cleanProcess()
            }
        }
    }

    private fun cleanProcess() {
        val deleteFile = mutableListOf<QuickFileModel>()
        viewModel.largeFileDelete.value?.let {
            deleteFile.addAll(it)
        }

        viewModel.duplicateFileDelete.value?.let {
            deleteFile.addAll(it)
        }
        viewModel.installedApkDelete.value?.let {
            deleteFile.addAll(it)
        }

        viewModel.trashDelete.value?.let {
            deleteFile.addAll(it)
        }


        Helper.deleteFiles(deleteFile, deleteDone)
    }

    private fun initializeLiveData() {
        viewModel.largeFile.observe(this) {
            Log.e(TAG, "initializeLiveData: Large File", )
            if (viewModel.largeFileSearched) {
                binding.pbLargeFile.visibility = GONE
                binding.ivLargeFileDown.visibility = VISIBLE
                binding.tvLargeFileStatus.text =
                    updateSelectionText(0, viewModel.largeFileSize, 0, it.size.toLong())

                viewModel.largeFileDelete.value = it.toMutableList()
                viewModel.largeDeleteFileSize.value = viewModel.largeFileSize
                val adapter = QuickFilesAdapter(
                    context = this,
                    it.toMutableList(),
                    viewModel.largeFileDelete,
                    viewModel.largeDeleteFileSize,
                    binding.cbLargeFile
                )
                binding.lvLargeFile.removeAllViews()
                for (i in it.indices) {
                    val view = adapter.getView(i, null, binding.lvLargeFile)
                    binding.lvLargeFile.addView(view)
                }

                binding.cbLargeFile.setOnCheckedChangeListener { compoundButton, isChecked ->
                    if (isChecked) adapter.selectAll() else adapter.clearAll()
                }
            }
        }
        viewModel.largeDeleteFileSize.observe(this) {
            binding.tvLargeFileStatus.text = updateSelectionText(
                it,
                viewModel.largeFileSize,
                viewModel.largeFileDelete.value!!.size.toLong(),
                viewModel.largeFile.value!!.size.toLong()
            )
            updateDeleteLayout()

        }


        viewModel.duplicateFile.observe(this) {
            if (viewModel.duplicateFileSearched) {

                binding.pbDuplicateFile.visibility = GONE
                binding.ivDuplicateFileDown.visibility = VISIBLE
                binding.tvDuplicateStatus.text = updateSelectionText(0, viewModel.duplicateFileSize, 0, it.size.toLong())



                val fileList: MutableList<QuickFileModel> = mutableListOf()
                var size: Long = 0
                
                for(i in it.entries){
                    for(x in i.value){
                        size+=x.fileSize
                        fileList.add(x)
                    }
                }
                val newFileList = mutableListOf<QuickFileModel>()
                newFileList.addAll(fileList)
                viewModel.duplicateFileDelete.value =newFileList
                viewModel.duplicateDeleteSize.value = size

                Log.e(TAG, "initializeLiveData: ${fileList.size}", )
                val adapter = QuickFilesAdapter(
                    this,
                    fileList,
                    viewModel.duplicateFileDelete,
                    viewModel.duplicateDeleteSize,
                    binding.cbDuplicateFile
                )

                binding.lvDuplicateFile.removeAllViews()
                if(fileList.isNotEmpty()){
                    for (i in 0 until fileList.size) {
                        val view = adapter.getView(i, null, binding.lvDuplicateFile)
                        binding.lvDuplicateFile.addView(view)
                    }
                }

                binding.cbDuplicateFile.setOnCheckedChangeListener { _, isChecked ->
                    if (isChecked) adapter.selectAll() else adapter.clearAll()
                }
            }

        }
        viewModel.duplicateDeleteSize.observe(this) {

            binding.tvDuplicateStatus.text = updateSelectionText(
                it,
                viewModel.duplicateFileSize,
                viewModel.duplicateFileDelete.value!!.size.toLong(),
                viewModel.duplicateFile.value!!.size.toLong()
            )
            updateDeleteLayout()
        }


        viewModel.installedApk.observe(this) {
            if (viewModel.installApkSearched) {

                binding.pbInstalled.visibility = GONE
                binding.ivInstalledApkDown.visibility = VISIBLE
                binding.tvInstalledStatus.text =
                    updateSelectionText(0, viewModel.installedApkSize, 0, it.size.toLong())


                val newList = mutableListOf<QuickFileModel>()
                newList.addAll(it)
                viewModel.installedApkDelete.value = newList
                viewModel.installedApkDeleteSize.value = viewModel.installedApkSize
                val adapter = QuickFilesAdapter(
                    this,
                    it.toMutableList(),
                    viewModel.installedApkDelete,
                    viewModel.installedApkDeleteSize,
                    binding.cbInstalledApk
                )

                binding.lvInstalledApk.removeAllViews()

                for (i in it.indices) {
                    val view = adapter.getView(i, null, binding.lvInstalledApk)
                    binding.lvInstalledApk.addView(view)
                }

                binding.cbInstalledApk.setOnCheckedChangeListener { compoundButton, isChecked ->
                    if (isChecked) adapter.selectAll() else adapter.clearAll()
                }
            }

        }
        viewModel.installedApkDeleteSize.observe(this) {
            binding.tvInstalledStatus.text = updateSelectionText(
                it,
                viewModel.installedApkDeleteSize.value!!,
                viewModel.installedApkDelete.value!!.size.toLong(),
                viewModel.installedApk.value!!.size.toLong()
            )
            updateDeleteLayout()

        }


        viewModel.trashFile.observe(this) {

            if (viewModel.trashFileSearched) {

                binding.pbTrash.visibility = GONE
                binding.ivTrashDown.visibility = VISIBLE
                binding.tvTrashStatus.text =
                    updateSelectionText(0, viewModel.trashFileSize, 0, it.size.toLong())


                val newList= mutableListOf<QuickFileModel>()
                newList.addAll(it)
                viewModel.trashDelete.value = newList
                viewModel.trashDeleteSize.value = viewModel.trashFileSize
                val adapter = QuickFilesAdapter(
                    this,
                    it.toMutableList(),
                    viewModel.trashDelete,
                    viewModel.trashDeleteSize,
                    binding.cbTrashFile
                )

                binding.lvTrash.removeAllViews()
                for (i in it.indices) {
                    val view = adapter.getView(i, null, binding.lvTrash)
                    binding.lvTrash.addView(view)
                }

                binding.cbTrashFile.setOnCheckedChangeListener { compoundButton, isChecked ->
                    if (isChecked) adapter.selectAll() else adapter.clearAll()
                }
            }

        }
        viewModel.trashDeleteSize.observe(this) {
            binding.tvTrashStatus.text = updateSelectionText(
                it,
                viewModel.trashFileSize,
                viewModel.trashDelete.value!!.size.toLong(),
                viewModel.trashFile.value!!.size.toLong()
            )
            updateDeleteLayout()
        }
    }

    private fun updateSelectionText(
        deleteFileSize: Long,
        totalFileSize: Long,
        deleteFileCount: Long,
        totalCount: Long
    ): String {
        return "${Helper.formatSize(deleteFileSize)}/${Helper.formatSize(totalFileSize)} || ${deleteFileCount}/${totalCount} Items"
    }

    private fun updateDeleteLayout() {
        deleteDone.value = false
        val size: Long =
            viewModel.largeDeleteFileSize.value!! + viewModel.duplicateDeleteSize.value!! + viewModel.installedApkDeleteSize.value!! + viewModel.trashDeleteSize.value!!

        binding.tvFinalTotalText.text = "Tap to clean"
        binding.tvFinalTotalClean.text = Helper.formatSize(size)

    }

    private fun flipVisibility(down: ImageView, list: LinearLayout) {
        if (down.rotation.toInt() == 0 || down.rotation.toInt() == 360) {
            down.rotation = 0f
            down.animate().rotation(180f).setDuration(shortAnimationDuration.toLong())
                .setListener(null)
        } else {
            down.animate().rotation(360f).setDuration(shortAnimationDuration.toLong())
                .setListener(null)
        }

        list.apply {
            if (visibility == VISIBLE) {
                alpha = 1f
                animate().alpha(0f).setDuration(shortAnimationDuration.toLong())
                    .setListener(object :
                        AnimatorListenerAdapter() {
                        override fun onAnimationEnd(animation: Animator) {
                            visibility = GONE
                        }
                    })
            } else {
                alpha = 0f
                visibility = VISIBLE
                animate().alpha(1f).setDuration(shortAnimationDuration.toLong()).setListener(null)
            }
        }
    }


}