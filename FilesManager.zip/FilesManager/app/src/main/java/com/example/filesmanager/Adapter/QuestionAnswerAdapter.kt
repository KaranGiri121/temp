package com.example.filesmanager.Adapter

import android.app.Activity
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.example.filesmanager.R


class QuestionAnswerAdapter(val context: Activity, val arr: List<Pair<String, String>>) :
    ArrayAdapter<Pair<String, String>>(context, 0, arr) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view = convertView

        if (view == null) {
            view = LayoutInflater.from(context)
                .inflate(R.layout.faq_question_answer, parent, false)
        }

        val question = view!!.findViewById<TextView>(R.id.question)
        val answer = view.findViewById<TextView>(R.id.answer)

        question.text = "${arr[position].first}"
        answer.text = "${arr[position].second}"
        return view
    }
}