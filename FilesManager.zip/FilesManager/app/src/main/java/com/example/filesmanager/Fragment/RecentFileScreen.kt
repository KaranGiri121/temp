package com.example.filesmanager.Fragment

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.filesmanager.Adapter.RecentFileAdapter
import com.example.filesmanager.DB.RecentFileDB
import com.example.filesmanager.DB.RecentFileEntity
import com.example.filesmanager.databinding.FragmentRecentFileScreenBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RecentFileScreen : Fragment() {

    private lateinit var binding: FragmentRecentFileScreenBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentRecentFileScreenBinding.inflate(inflater, container, false)

        CoroutineScope(Dispatchers.IO).launch {

            val allRecent = RecentFileDB.getInstance(requireContext()).getRecentDao()
                .getAllRecentSortByDescending()
            val newRecent = mutableListOf<RecentFileEntity>()

            val thirtyDay = System.currentTimeMillis() - (30L * 24 * 60 * 60 * 1000)
            for( i in allRecent){
                if(i.openTime>thirtyDay){
                    newRecent.add(i)
                }else{
                    RecentFileDB.getInstance(requireContext()).getRecentDao().deleteRecentFile(i)
                }
            }
            Handler(Looper.getMainLooper()).post {
                if (allRecent.isNotEmpty()) {
                    binding.pbRecentFile.visibility = GONE
                    binding.rvRecentFiles.visibility = VISIBLE
                    val recentAdapter = RecentFileAdapter(requireContext(), newRecent)
                    binding.rvRecentFiles.adapter = recentAdapter
                    binding.rvRecentFiles.layoutManager = LinearLayoutManager(requireContext())
                } else {
                    binding.pbRecentFile.visibility = GONE
                    binding.tvRecentStatus.visibility = VISIBLE
                }

            }

        }
        return binding.root
    }


}