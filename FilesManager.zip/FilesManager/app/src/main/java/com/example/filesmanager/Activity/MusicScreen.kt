package com.example.filesmanager.Activity

import android.os.Bundle
import android.view.View.GONE
import android.view.View.VISIBLE
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.filesmanager.Adapter.MusicListAdapter
import com.example.filesmanager.Utils.CommonViewModel
import com.example.filesmanager.databinding.ActivityMusicScreenBinding

class MusicScreen : AppCompatActivity() {
    private lateinit var binding: ActivityMusicScreenBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMusicScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.appbar.backBtn.setOnClickListener {
            finish()
        }

        binding.appbar.appTitle.text = "Musics"
        val viewModel = CommonViewModel.viewModel
        if (!viewModel.musicSearched) {
            viewModel.getAllMusic(contentResolver)
        }
        val musicAdapter = MusicListAdapter(this,viewModel.allMusics.value ?: listOf())
        binding.rvMusic.adapter = musicAdapter
        binding.rvMusic.layoutManager = LinearLayoutManager(this)


        viewModel.allMusics.observe(this) {
            if (it != null) {
                if (it.isEmpty()) {
                    if (viewModel.musicSearched) {
                        binding.tvMusicStatus.visibility = VISIBLE
                        binding.rvMusic.visibility = GONE
                        binding.pbMusicScreen.visibility = GONE
                    }
                } else {
                    binding.pbMusicScreen.visibility = GONE
                    binding.tvMusicStatus.visibility = GONE
                    binding.rvMusic.visibility = VISIBLE
                    musicAdapter.update(it)
                }
            } else {
                if (viewModel.musicSearched) {
                    binding.tvMusicStatus.visibility = VISIBLE
                    binding.rvMusic.visibility = GONE
                    binding.pbMusicScreen.visibility = GONE
                }

            }
        }
    }
}