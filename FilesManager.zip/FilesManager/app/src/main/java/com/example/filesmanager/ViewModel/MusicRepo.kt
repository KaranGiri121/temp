package com.example.filesmanager.ViewModel

import android.content.ContentResolver
import android.provider.MediaStore
import com.example.filesmanager.Model.MusicModel

class MusicRepo {



    fun getAllMusic(
        contentResolver: ContentResolver
    ): List<MusicModel>{

        val musicList: MutableList<MusicModel> = mutableListOf()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.ARTIST
        )



        val pointer = contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,projection,null,null,null)
        if(pointer!=null){
            while(pointer.moveToNext()){
                val id = pointer.getLong(0)
                val fileName = pointer.getString(1)
                val fileSize = pointer.getLong(2)
                val duration = pointer.getLong(3)
                val albumId = pointer.getLong(pointer.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID))

                musicList.add(MusicModel(id,fileName,fileSize,duration,albumId,pointer.getString(5)))
            }
        }

        return musicList
    }
}