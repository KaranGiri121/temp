package com.example.filesmanager.Activity

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class TempViewModel:ViewModel() {


    val tempArr :MutableList<String> = mutableListOf()
    val tempList : MutableLiveData<MutableList<String>> = MutableLiveData(tempArr)


    fun update(){
    }

    fun updateNotifiy(){
        val temp = tempList.value!!
        temp.add("Hello")

        tempList.value = temp
    }
}