package com.example.filesmanager.Interface

enum class FileExtension {
    Image,
    Video,
    APK,
    Other
}