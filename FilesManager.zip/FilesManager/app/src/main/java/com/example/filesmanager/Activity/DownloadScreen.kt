package com.example.filesmanager.Activity

import android.os.Bundle
import android.util.Log
import android.view.View.GONE
import android.view.View.VISIBLE
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.filesmanager.Adapter.DownloadFilesAdapter
import com.example.filesmanager.Utils.CommonViewModel
import com.example.filesmanager.databinding.ActivityDownloadScreenBinding


class DownloadScreen : AppCompatActivity() {

    private final val TAG = "DownloadScreen"
    private lateinit var binding: ActivityDownloadScreenBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDownloadScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.appbar.appTitle.text = "Downloads"
        binding.appbar.backBtn.setOnClickListener {
            finish()
        }
        val viewModel = CommonViewModel.viewModel
        viewModel.getAllDownloadContent(contentResolver)
        val downloadAdapter = DownloadFilesAdapter(this,viewModel.allDownloadContents.value ?: listOf())
        binding.rvDownloadFiles.adapter = downloadAdapter
        binding.rvDownloadFiles.layoutManager = LinearLayoutManager(this)
        viewModel.allDownloadContents.observe(this) { it ->
            it?.let { list ->
                if (list.isNotEmpty()) {
                    binding.tvDownloadFolderStatus.visibility = GONE
                    binding.rvDownloadFiles.visibility = VISIBLE
                    downloadAdapter.update(list)
                }
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {

        Log.e(TAG, "onRequestPermissionsResult: $requestCode")
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }
}