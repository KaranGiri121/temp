package com.example.filesmanager.ViewModel

import android.content.ContentResolver
import android.content.Context
import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.filesmanager.Model.AppModel
import com.example.filesmanager.Model.DocsModel
import com.example.filesmanager.Model.DownloadModel
import com.example.filesmanager.Model.ImageModel
import com.example.filesmanager.Model.MusicModel
import com.example.filesmanager.Model.NewFileModel
import com.example.filesmanager.Model.VideoModel
import kotlinx.coroutines.runBlocking

class StorageViewModel() : ViewModel() {

    private final val TAG = "StorageViewModel"

    val allImages: MutableLiveData<Map<String, List<ImageModel>>> = MutableLiveData(mapOf())
    var allImagesSize: Long = 0
    var imageSearched: Boolean = false

    val allVideos: MutableLiveData<Map<String, List<VideoModel>>> = MutableLiveData(mapOf())
    var allVideosSize: Long = 0
    var videoSearched: Boolean = false

    val allDocs: MutableLiveData<List<DocsModel>> = MutableLiveData(listOf())
    var allDocsSize: Long = 0
    var docsSearched: Boolean = false

    val allDownloadContents: MutableLiveData<List<DownloadModel>> = MutableLiveData(listOf())
    var downloadSearched: Boolean = false

    val allNewFiles: MutableLiveData<List<NewFileModel>> = MutableLiveData(listOf())
    var newFiledSearched: Boolean = false

    val allMusics: MutableLiveData<List<MusicModel>> = MutableLiveData(listOf())
    var musicsSize: Long = 0
    var musicSearched: Boolean = false

    val allAppInformation: MutableLiveData<List<AppModel>> = MutableLiveData(listOf())
    var appInformationSearched: Boolean = false
    var appTotalSize: Long = 0

    fun getAllImage(contentResolver: ContentResolver) {

        val allImage = ImageRepo().getAllImage(contentResolver)
        allImage.let {
            for (key in it.keys) {
                for (values in it[key]!!) {
                    allImagesSize += values.fileSize
                }
            }
        }
        imageSearched = true
        allImages.postValue(allImage)
    }

    fun getAllVideo(contentResolver: ContentResolver) {
        val allVideo = VideoRepo().getAllVideo(contentResolver)

        allVideo.let {
            for (key in it.keys) {
                for (values in it[key]!!) {
                    allVideosSize += values.fileSize
                }
            }
        }

        videoSearched = true
        allVideos.postValue(allVideo)
    }

    fun getAllDocs(contentResolver: ContentResolver) {
        val allDoc = DocsRepo().getAllDoc(contentResolver)
        allDoc.let {
            for (i in it) {
                allDocsSize += i.fileSize
            }
        }

        docsSearched = true
        allDocs.postValue( allDoc)
    }

    fun getAllDownloadContent(contentResolver: ContentResolver) {
        val allDownload = DownloadRepo().getAllDownloadFile(contentResolver)

        downloadSearched = true
        allDownloadContents.postValue(allDownload)
    }


    fun getAllNewFiles(contentResolver: ContentResolver) {
        val allFile = NewFileRepo().getAllNewFile(contentResolver)

        newFiledSearched = true
        allNewFiles.postValue(allFile)
    }


    fun getAllMusic(contentResolver: ContentResolver) {
        val allMusic = MusicRepo().getAllMusic(contentResolver)
        allMusic.let {
            for (i in it) {
                musicsSize += i.fileSize
            }
        }
        Log.e(TAG, "getAllMusic: $musicsSize", )
        musicSearched = true
        allMusics.postValue( allMusic)

    }

    fun getAllAppInfo(context: Context) {
        runBlocking {
            val allApp = AppRepo().getAllAppInfo(context)
            appInformationSearched = true
            allAppInformation.postValue(allApp)
            allAppInformation.value?.let {
                for (i in it) {
                    appTotalSize += i.occupiedSize
                }
            }
        }
    }
}