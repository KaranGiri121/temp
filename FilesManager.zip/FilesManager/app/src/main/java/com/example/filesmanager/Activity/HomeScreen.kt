package com.example.filesmanager.Activity

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import androidx.lifecycle.ViewModelProvider
import com.example.filesmanager.Fragment.CleanScreen
import com.example.filesmanager.Fragment.DashboardScreen
import com.example.filesmanager.Fragment.RecentFileScreen
import com.example.filesmanager.R
import com.example.filesmanager.Utils.CommonViewModel
import com.example.filesmanager.ViewModel.QuickScanViewModel
import com.example.filesmanager.ViewModel.QuickScanViewModelFactory
import com.example.filesmanager.ViewModel.StorageViewModel
import com.example.filesmanager.databinding.ActivityHomeScreenBinding

class HomeScreen : AppCompatActivity() {

    private lateinit var binding: ActivityHomeScreenBinding
    private val TAG = "HomeScreen"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val fragmentManager = supportFragmentManager
        val fragmentTransition = fragmentManager.beginTransaction();
        fragmentTransition.replace(binding.homeScreenFragment.id, DashboardScreen())
        fragmentTransition.commit()


        val viewMode = ViewModelProvider(this)[StorageViewModel::class.java]
        val cleanViewModel = ViewModelProvider(
            this,
            QuickScanViewModelFactory(application)
        )[QuickScanViewModel::class.java]
        CommonViewModel.viewModel = viewMode
        CommonViewModel.cleanViewModel = cleanViewModel

        binding.ivClean.setOnClickListener {
            val newFragmentManager = supportFragmentManager

            var something = newFragmentManager.findFragmentById(binding.homeScreenFragment.id)

            if (something?.javaClass != CleanScreen::class.java) {
                Log.e(TAG, "onCreate: Clean")
                val newFragmentTransition = newFragmentManager.beginTransaction();

                newFragmentTransition.replace(binding.homeScreenFragment.id, CleanScreen())
                newFragmentTransition.addToBackStack("CleanScreen")
                newFragmentTransition.commit()
            }
            binding.ivFiles.setImageDrawable(
                AppCompatResources.getDrawable(
                    this,
                    R.drawable.ic_unselect_file
                )
            )
            binding.ivRecent.setImageDrawable(
                AppCompatResources.getDrawable(
                    this,
                    R.drawable.ic_unselected_recent
                )
            )
        }

        binding.ivFiles.setOnClickListener {
            val newFragmentManager = supportFragmentManager
            var something = newFragmentManager.findFragmentById(binding.homeScreenFragment.id)

            if (something?.javaClass != DashboardScreen::class.java) {
                val newFragmentTransition = newFragmentManager.beginTransaction();

                newFragmentTransition.replace(binding.homeScreenFragment.id, DashboardScreen())
                newFragmentTransition.addToBackStack("Dashboard")
                newFragmentTransition.commit()
            }
            binding.ivFiles.setImageDrawable(
                AppCompatResources.getDrawable(
                    this,
                    R.drawable.ic_files
                )
            )
            binding.ivRecent.setImageDrawable(
                AppCompatResources.getDrawable(
                    this,
                    R.drawable.ic_unselected_recent
                )
            )
        }

        binding.ivRecent.setOnClickListener {
            val newFragmentManager = supportFragmentManager
            var something = newFragmentManager.findFragmentById(binding.homeScreenFragment.id)

            if (something?.javaClass != RecentFileScreen::class.java) {
                val newFragmentTransition = newFragmentManager.beginTransaction();
                newFragmentTransition.replace(binding.homeScreenFragment.id, RecentFileScreen())
                newFragmentTransition.addToBackStack("RecentFile")
                newFragmentTransition.commit()
            }
            binding.ivFiles.setImageDrawable(
                AppCompatResources.getDrawable(
                    this,
                    R.drawable.ic_unselect_file
                )
            )
            binding.ivRecent.setImageDrawable(
                AppCompatResources.getDrawable(
                    this,
                    R.drawable.ic_recent
                )
            )
        }


    }
}