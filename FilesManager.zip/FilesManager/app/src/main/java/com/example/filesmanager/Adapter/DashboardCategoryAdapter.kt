package com.example.filesmanager.Adapter

import android.app.Activity
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.PendingIntent.FLAG_MUTABLE
import android.content.ContentUris
import android.content.Context
import android.content.Context.NOTIFICATION_SERVICE
import android.content.Intent
import android.graphics.Color
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.filesmanager.Activity.AppScreen
import com.example.filesmanager.Activity.DocsScreen
import com.example.filesmanager.Activity.DownloadScreen
import com.example.filesmanager.Activity.FtpServerScreen
import com.example.filesmanager.Activity.ImageFolderScreen
import com.example.filesmanager.Activity.MusicScreen
import com.example.filesmanager.Activity.NewFileScreen
import com.example.filesmanager.Activity.StoreAnalysis
import com.example.filesmanager.Activity.VideoFolderScreen
import com.example.filesmanager.Model.DashboardCategoryModel
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper


class DashboardCategoryAdapter(
    val context: Context,
    val activity: Activity,
    val dashBoardItems: List<DashboardCategoryModel>
) :


    RecyclerView.Adapter<DashboardCategoryAdapter.DashboardCategoryViewHolder>() {
    var TAG = "DashBoardCategoryAdapter"

    class DashboardCategoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val dashBoardItem =
            itemView.findViewById<LinearLayout>(com.example.filesmanager.R.id.ll_dashboard_card)
        val dashBoardCard =
            itemView.findViewById<CardView>(com.example.filesmanager.R.id.cv_dashBoard_card)
        val dashBoardImage =
            itemView.findViewById<ImageView>(com.example.filesmanager.R.id.iv_dashBoard_image)
        val dashBoardText =
            itemView.findViewById<TextView>(com.example.filesmanager.R.id.iv_dashBoard_text)
    }

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): DashboardCategoryViewHolder {
        val view =
            LayoutInflater.from(parent.context)
                .inflate(com.example.filesmanager.R.layout.dash_board_items, parent, false)
        return DashboardCategoryViewHolder(view)
    }

    override fun getItemCount(): Int {
        return dashBoardItems.size
    }

    override fun onBindViewHolder(holder: DashboardCategoryViewHolder, position: Int) {
        holder.dashBoardItem.setOnClickListener {
            when (dashBoardItems[position].iconName) {
                "Docs" -> {
                    if (Helper.storagePermission(context, activity)) {
                        val newIntent = Intent(context, DocsScreen::class.java)
                        context.startActivity(newIntent)
                    }
                }

                "Images" -> {
                    if (Helper.storagePermission(context, activity)) {
                        val newIntent = Intent(context, ImageFolderScreen::class.java)
                        context.startActivity(newIntent)
                    }
                }

                "Videos" -> {
                    if (Helper.storagePermission(context, activity)) {

                        val newIntent = Intent(context, VideoFolderScreen::class.java)
                        context.startActivity(newIntent)
                    }
                }

                "Download" -> {
                    if (Helper.storagePermission(context, activity)) {

                        val newIntent = Intent(context, DownloadScreen::class.java)
                        context.startActivity(newIntent)
                    }
                }

                "New Files" -> {
                    if (Helper.storagePermission(context, activity)) {

                        val newIntent = Intent(context, NewFileScreen::class.java)
                        context.startActivity(newIntent)
                    }
                }

                "Store analysis" -> {
                    if (Helper.storagePermission(context, activity)) {

                        val newIntent = Intent(context, StoreAnalysis::class.java)
                        context.startActivity(newIntent)
                    }
                }

                "Audios" -> {
                    if (Helper.storagePermission(context, activity)) {

                        val newIntent = Intent(context, MusicScreen::class.java)
                        context.startActivity(newIntent)
                    }
                }

                "Apps" -> {
                    val newIntent = Intent(context, AppScreen::class.java)
                    context.startActivity(newIntent)
                }

                "Remote" -> {
                    if (Helper.storagePermission(context, activity)) {
                        val newIntent = Intent(context, FtpServerScreen::class.java)
                        context.startActivity(
                            newIntent
                        )
                    }
                }

                "Access From..." -> {

                    val mediaSession = MediaSession(context, "PlayerService")
                    val mediaStyle =
                        Notification.MediaStyle().setMediaSession(mediaSession.sessionToken)
                            .setShowActionsInCompactView(0, 1, 2)


                    val tempIntent = Intent(context, MusicScreen::class.java);
                    val pendingIntent: PendingIntent = PendingIntent.getActivity(
                        context,
                        121,
                        tempIntent,
                        PendingIntent.FLAG_UPDATE_CURRENT or FLAG_MUTABLE
                    )

                    val pauseAction: Notification.Action = Notification.Action.Builder(
                        R.drawable.ic_pause_btn, "Pause", pendingIntent
                    ).build()

                    val playAction: Notification.Action = Notification.Action.Builder(
                        R.drawable.ic_play_btn_drawable, "Play", pendingIntent
                    ).build()

                    val nextAction = Notification.Action.Builder(
                        R.drawable.ic_next_btn, "Next", pendingIntent
                    ).build()
//
                    val previousAction = Notification.Action.Builder(
                        R.drawable.ic_previous_btn, "Previous", pendingIntent
                    ).build()

                    val notification = Notification.Builder(context,"12")
                        .setStyle(mediaStyle)
                        .setSmallIcon(R.drawable.ic_apps)


                    notification.addAction(pauseAction)
//                    val notification = Notification.Builder(context, "12")
//                        .setStyle(mediaStyle)
//                        .setSmallIcon(R.drawable.ic_apps)
//                        .addAction(previousAction)
//                        .addAction(playAction)
//                        .addAction(nextAction)


                    mediaSession.setMetadata(
                        MediaMetadata.Builder()
                            .putString(MediaMetadata.METADATA_KEY_TITLE, "musicPiece.fileName")
                            .putString(MediaMetadata.METADATA_KEY_ARTIST, "musicPiece.artistName")
                            .putString(
                                MediaMetadata.METADATA_KEY_ALBUM_ART_URI,
                                ContentUris.withAppendedId(Helper.imageUri, 1000000055).toString()
                            )
                            .putLong(
                                MediaMetadata.METADATA_KEY_DURATION,
                                120L
                            )
                            .build()
                    )

                    mediaSession.setPlaybackState(
                        PlaybackState.Builder()
                            .setState(
                                PlaybackState.STATE_PLAYING,
                                12,
                                1F
                            )
                            .setActions(PlaybackState.ACTION_SEEK_TO)
                            .build()
                    )

//                    something.setMetadata(
//                        MediaMetadata.Builder()
//
//                            // Title.
//                            .putString(MediaMetadata.METADATA_KEY_TITLE, "Hello")
//
//                            // Artist.
//                            // Could also be the channel name or TV series.
//                            .putString(MediaMetadata.METADATA_KEY_ARTIST, "World")
//
//                            // Album art.
//                            // Could also be a screenshot or hero image for video content
//                            // The URI scheme needs to be "content", "file", or "android.resource".
//
//
//                            .putLong(
//                                MediaMetadata.METADATA_KEY_DURATION,
//                                120
//                            ) // 4
//
//                            .build()
//                    )
//
//                    something.setPlaybackState(
//
//                        PlaybackState.Builder()
//                            .setState(
//                                PlaybackState.STATE_PLAYING,
//                                11,
//                                1F
//                            )
//                            .setActions(PlaybackState.ACTION_SEEK_TO)
//                            .build()
//                    )


                    val notificationManager =
                        context.getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                    notificationManager.notify(121, notification.build())
                }


            }
        }
        holder.dashBoardCard.setCardBackgroundColor(Color.parseColor(dashBoardItems[position].colorString))
        holder.dashBoardText.text = dashBoardItems[position].iconName
        holder.dashBoardImage.setImageResource(dashBoardItems[position].icon)
    }
}