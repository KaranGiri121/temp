package com.example.filesmanager.Model

data class QuickFileModel(val id:Long, val fileName:String, val filePath:String, val fileSize: Long, val fileData:String, val fileType:String,
                          var iSelected:Boolean = false)
