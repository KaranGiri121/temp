package com.example.filesmanager.Activity

import android.os.Bundle
import android.view.View.GONE
import android.view.View.VISIBLE
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.filesmanager.Adapter.NewFileAdapter
import com.example.filesmanager.Utils.CommonViewModel
import com.example.filesmanager.databinding.ActivityNewFileScreenBinding

class NewFileScreen : AppCompatActivity() {
    private lateinit var binding : ActivityNewFileScreenBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNewFileScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.appbar.appTitle.text = "New File"
        binding.appbar.backBtn.setOnClickListener {
            finish()
        }
        val viewModel = CommonViewModel.viewModel
        if(!viewModel.newFiledSearched){
            viewModel.getAllNewFiles(contentResolver)
        }

        val adapter = NewFileAdapter(this,viewModel.allNewFiles.value?: listOf())
        binding.rvNewFile.adapter = adapter
        binding.rvNewFile.layoutManager = LinearLayoutManager(this)
        viewModel.allNewFiles.observe(this){
            if(it!=null){
                if(it.isEmpty()){
                    binding.rvNewFile.visibility = GONE
                    binding.tvNewFileStatus.visibility = VISIBLE
                }else{
                    adapter.update(it)
                }
            }else{
                binding.rvNewFile.visibility = GONE
                binding.tvNewFileStatus.visibility = VISIBLE
            }
        }

    }
}