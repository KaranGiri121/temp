package com.example.filesmanager.Utils

class StringConstant {
    companion object{
        val proEnable  = "isProEnable"
        val onBoarding = "showOnBoarding"
        val privacy = "showPrivacy"
        val packageName = "FileManager"

        val inAppImage = "inAppImage"
        val inAppVideo = "inAppVideo"
        val inAppMusic = "inAppMusic"

        val deleteDialogConsent = "showDeleteDialog"
    }
}