package com.example.filesmanager.DB

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface RecentFileDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertRecent(recentFile:RecentFileEntity)

    @Query("SELECT * FROM recentfileentity")
    fun getAllRecentFiles(): List<RecentFileEntity>

    @Query("SELECT * FROM recentfileentity ORDER BY openTime ASC")
    fun getAllRecentSortByAscending(): List<RecentFileEntity>

    @Query("SELECT * FROM recentfileentity ORDER BY openTime DESC")
    fun getAllRecentSortByDescending(): List<RecentFileEntity>

    @Delete
    fun deleteRecentFile(recentFile: RecentFileEntity)
}